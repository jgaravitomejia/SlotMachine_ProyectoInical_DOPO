

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * SlotMachineContest unit tests (Cycle 3).
 *
 * Solve(n) internally creates a random (invisible) machine and returns the
 * list of actions {wheel, steps}. Since that machine is internal, these tests
 * verify properties of the action list that must always hold true:
 * - the list is not null,
 * - each action is a valid {wheel, steps} pair,
 * - the wheels are within the range 1..n,
 * - the problem's limit of 10,000 actions is not exceeded,
 * - no moves are made in trivial cases (n <= 1).
 */
public class SlotMachineContestTest{
    private SlotMachineContest contest;
    /**
     *It runs before each test: it creates a new resolver.
     */
    @BeforeEach
    public void setUp(){
        contest = new SlotMachineContest();
    }
    
    /**
     * It runs after eact test
     */
    @AfterEach
    public void tearDown(){
        
    }
    
    @Test
    public void shouldNotReturnNull(){
        int[][] actions = contest.solve(5);
        assertNotNull(actions); //solve nunca devuelve null
    }
    
    @Test
    public void shouldReturnPairsOfTwoValues(){
        int[][] actions = contest.solve(6);
        for(int[] action:actions){
            assertEquals(2, action.length); 
            //cada accion debe ser {rueda,pasos}
        }
    }
    
    @Test
    public void shouldUseWheelsInvalidRange(){
        int n=7;
        int[][] actions = contest.solve(n);
        for(int[] action: actions){
            int wheel = action[0];
            assertTrue(wheel >=1 && wheel <= n); //la rueda esta entre 1 y n
        }
    }
    
    @Test
    public void shouldUseNonZeroSteps(){
        int[][] actions = contest.solve(8);
        for(int[] action: actions){
            assertNotEquals(0, action[1]); //no tiene sentido girar 9 pasos
        }
    }
    
    //lo que no debe hacer
    
    @Test
    public void shouldNotActWithSingleWheel(){
        //con una sola rueda ya es jackpot, no se resuleve
        int[][] actions = contest.solve(1);
        assertEquals(0, actions.length);
    }
    
    @Test
    public void shouldNotActWithZeroSize(){
        //tamaño invalido, no debe hacer ningun movimiento
        int[][] actions = contest.solve(0);
        assertEquals(0, actions.length);
    }
}