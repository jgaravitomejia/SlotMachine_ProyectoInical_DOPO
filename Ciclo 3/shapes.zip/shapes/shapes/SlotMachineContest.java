import java.util.ArrayList;

public class SlotMachineContest{
    
    /**
     * Solves a machine of size n in invisible mode and returns the list of
     * actions {wheel, steps} taken to reach the jackpot. 
     *@param n number of reels and symbols.
     *@return result array of actions, each action is {wheel, steps}.
     */
    public int[][] solve(int n){
        SlotMachine machine = new SlotMachine(n); //se crea invisible
        ArrayList<int[]> actions = new ArrayList<int[]>(); //anotamos cada movimiento/acciones
        resolve(machine, actions); //resuelve registrando cada movimiento
        //convertimos la lista de acciones a un arreglo para devolverlo 
        int[][] result = new int[actions.size()][];
        for(int a=0; a<actions.size(); a++){
            result[a] = actions.get(a);
        }
        return result;
    }
    
    /**
     * Simulates the solution in visible mode: creates the machine, displays it, and
     * solves it so the process is visible.
     * @param n number of reels and symbols.
     */
    public void simulate(int n){
        SlotMachine machine = new SlotMachine(n);
        machine.makeVisible(); //si se ve
        resolve(machine, null); //null= no anotamos acciones
        
    }
    
    /**
     * Operates on the machine using only distinctSymbols() and spin(wheel, steps). 
     * If actions is not null, records each rotation as {i, j}.It records each movement.
     * @param machine the machine to be solved.
     * @param actions list where actions are to be recorded, or null to not record them.
     */
    private void resolve(SlotMachine machine, ArrayList<int[]> actions){
        int n = machine.symbols().length; //numero de ruedas/simbolos
        if(n <=1 || machine.distinctSymbols() ==1){
            return;  //si no hay nada que resolver, una sola rueda o ya es jackpot, acaba
        }
        
        //primero, hacemos que la primera rueda tenga un simbolo unico, que nos sirve de ref
        makeWheelOneUnique(machine, n, actions);
        
        //segundo, para cada rueda, vamos a anotar cuantos paso hay que girarla para que
        //quede igual a la rueda 1 que todavia no giramos
        int[] rotation = new int[n + 1]; //rortation[i]=pasos (girar) para la rueda i
        for(int i = 2; i <= n; i++){
            rotation[i] = searchRotation(machine, i, n, actions);
        }
        //tercero, aplicamos todas las rotaciones, cada rueda queda en el simbolo de la 1
        for(int i = 2; i<=n; i++){
            if(rotation[i] >0){
                machine.spin(i, rotation[i]);
                takeNotes(actions,i,rotation[i]);
            }
        }
        
    }
    /**
     * Rotate wheel 1 to the position with the most distinct symbols, specifically,
     * to a symbol that no other wheel displays. 
     * This makes wheel 1 a unique reference point, allowing it to be detected when moved.
     *@param machine machine
     *@param n number of positions (symbols).
     *@param actions list to record (takeNote), or null.
     */
    private void makeWheelOneUnique(SlotMachine machine, int n, ArrayList<int[]> actions){
        int bestK = machine.distinctSymbols(); //distintos en la posicion incial
        int bestStep = 0; //mejor posicion encontrada
        //se gira la rueda 1 una vuelta completa buscando donde hay mas distintos 
        for(int step = 1; step <= n - 1; step++){
            machine.spin(1,1);
            takeNotes(actions, 1, 1); // i,j=1
            int k = machine.distinctSymbols();
            if(k > bestK){ //buscamos el maximo, osea, el simbolo unico
                bestK = k;
                bestStep = step; 
            }
        }
        //la rueda 1 esta en, inicio + n-1, casi al final de la vuelta 
        //la vamos a llevar al mejor paso, inicio + bestStep
        int remaining = ((bestStep -(n-1))%n + n)% n; //pasos que faltan
        if(remaining > 0){
            machine.spin(1, remaining);
            takeNotes(actions, 1, remaining);
        }
    }
    
    /**
     * Determine how many steps wheel *i* must be rotated to match wheel 1. 
     * Perform one rotation with wheel 1 stationary, and another with wheel 1 shifted
     * by one step; the position where the number of `distinctSymbols` increases the most
     * when moving wheel 1 corresponds to the alignment that matched wheel 1. 
     * Do not leave wheel *i* in the shifted position.
     * @param machine machine
     * @param i number of the wheel to be analyzed.
     * @param n number of positions (symbols).
     * @param actions list to record actions, or null.
     * @return best steps to rotate wheel i (0..n-1) to match wheel 1.
     */
    private int searchRotation(SlotMachine machine,int i,int n, ArrayList<int[]> actions){
        //vuelta 1: rueda 1  quieta, guardamos los distinctSymbols en cada posicion de i
        int[] withWheelOneStill = new int[n];
        withWheelOneStill[0] = machine.distinctSymbols();
        for(int step = 1; step <= n-1; step++){
            machine.spin(i,1);
            takeNotes(actions, i, 1);
            withWheelOneStill[step] = machine.distinctSymbols();
        }
        machine.spin(i,1); //completar la vuelta: la rueda i vuelve a su inicio
        takeNotes(actions, i, 1);
        
        machine.spin(1,1); // mover la rueda 1 un pasito
        takeNotes(actions,1,1);
        
        // vuelta 2: rueda 1 movida. Anotamos los distinctSymbols en cada posicion de i.
        int[] withWheelOneMoved = new int[n];
        withWheelOneMoved[0] = machine.distinctSymbols();
        for(int step=1; step<= n-1; step++){
            machine.spin(i,1);
            takeNotes(actions,i,1);
            withWheelOneMoved[step] = machine.distinctSymbols();
        }
        machine.spin(i,1); // la rueda i vuelve a su inicio
        takeNotes(actions,i,1);
        
        machine.spin(1,-1); // devolver la rueda 1 a donde estaba
        takeNotes(actions,1,-1);
        
        //// la posicion donde mas subieron los distinctSymbols al mover la rueda 1
        int bestStep = 0;
        int bestIncrease = Integer.MIN_VALUE; //valor inicial 
        for(int step =0; step<n; step++){
            int increase = withWheelOneMoved[step] - withWheelOneStill[step];
            if(increase > bestIncrease){
                bestIncrease = increase;
                bestStep = step;
            }
        }
        return bestStep;
        
        
    }
    /**
     * 
     * Register an action {i, j} in the list, if the list exists.
     * @param actions list of actions, or null.
     * @param i wheel number.
     * @param j steps turned.
     */
    private void takeNotes(ArrayList<int[]> actions, int i, int j){
        if(actions !=null){
            actions.add(new int[]{i,j});
        }
    }
}
