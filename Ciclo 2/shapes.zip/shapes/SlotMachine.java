import java.util.ArrayList;
import java.util.HashSet;
import javax.swing.JOptionPane;
/**
 * SlotMachine is the controler. Mantains a list that shows of symbols that define which color 
 * exists and in which order.
 * Each wheel haves their own symbols, so when one symbol is added or eliminated, slotmachine 
 * duplicates the change in all the wheels so al the wheels have the same changes (same symbols
 * in the same ordre)
 * 
 * @author Garavitom-RomanoG
 * @version Cicle 1
 */
public class SlotMachine
{
    private ArrayList<Wheel> wheels;
    private ArrayList<Symbol> symbols;
    private Rectangle body;
    private int bodyX, bodyY;
    private boolean isVisible;
    private boolean ok;
    /**
     * Create the SlotMachine empty
     */
    public SlotMachine(){
        symbols = new ArrayList<Symbol>();
        wheels = new ArrayList<Wheel>();
        body = new Rectangle();
        body.changeColor("gray");
        body.changeSize(120, 150);
        body.moveHorizontal(40 - 70);
        body.moveVertical(40 - 15);
        bodyX = 40;
        bodyY = 40;
        isVisible = false;
        ok = true;
    }
    
    /**
     * Add a wheel in the indicated position
     * @param pos position of the wheel that is inserted
     */
    public void addWheel(int pos){
        int max = wheels.size() + 1;
        int i = adjust(pos, max);
        ArrayList<Symbol> propios = new ArrayList<Symbol>();
        for(Symbol s : symbols){
            propios.add(new Symbol(s.getColor()));
        }
        Wheel w = new Wheel(propios, 0, 0);
        wheels.add(i - 1, w);
        if (isVisible){
            w.makeVisible();
        }
        refresh();
        ok = true;
    }
    
    /**
     * Delete the wheel in the indicated position
     * @param pos position of the wheel that will be deleted
     */
    public void delWheel(int pos){
        if (wheels.isEmpty()){
            ok = false;
            report("no hay ruedas para eliminar");
            return;
        }
        int max = wheels.size();
        int i = adjust(pos, max);
        wheels.get(i - 1).makeInvisible();
        wheels.remove(i - 1);
        refresh();
        ok = true;
    }
    
    /**
     * Add a symbol (color CSS) in the indicated position.
     * It replicates in all the wheels to keep them the same.
     * @param pos position where the symbol is inserted
     * @param color name of the color from the standard CSS
     */
    public void addSymbol(int pos, String color){
        int max = symbols.size() + 1;
        int i = adjust(pos, max);
        symbols.add(i - 1, new Symbol(color));
        for(Wheel w : wheels){
            w.addSymbol(i - 1, color);
        }
        refresh();
        ok = true;
    }
    
    /**
     * Deletes the symbols of the indicated color (from the machine and all the wheels)
     * @param symbol color of the symbol that will be deleted.
     */
    public void delSymbol(String symbol){
        Symbol s = findSymbol(symbol);
        if (s == null){
            ok = false;
            report("No existe el simbolo de color "+ symbol + ".");
            return;
        }
        symbols.remove(s);
        for(Wheel w: wheels){
            w.delSymbol(symbol);
        }
        refresh();
        ok = true;
    }
    
    /**
     * Place a symbol in an specific wheel.
     * @param wheel number o f the wheel.
     * @param symbol color of the symbol to show in the wheel.
     */
    public void placeSymbol( int wheel, String symbol){
        Symbol s =  findSymbol(symbol);
        if(wheels.isEmpty() || s == null){
            ok = false;
            report("No se puede colocar el simbolo" + symbol + ".");
            return;
        }
        int max = wheels.size();
        int i = adjust(wheel, max);
        wheels.get(i-1).place(s);
        refresh();
        ok = true;
    }
    
    /**
     * Spin an specific wheel.
     * @param wheel number of the wheel
     */
    public void spin(int wheel){
        if(wheels.isEmpty()){
            ok = false;
            report("No hay ruedas para girar.");
            return;
        }
        int max = wheels.size();
        int i = adjust(wheel, max);
        if(wheels.get(i - 1).isLocked()){
            ok = false;
            report("La rueda" + i + " esta fija.");
            return;
        }
        wheels.get(i-1).spin();
        refresh();
        ok = true;
    }
    
    /**
     * Spin all the wheels
     */
    public void spin(){
        for(Wheel w : wheels){
            w.spin();
        }
        refresh();
        ok=true;
    }
    
    /**
     * Returns the color of the symbols in the machine, in order from 1
     * @return ArrayList with the colors of the symbols.
     */
    public String[] symbols(){
        String[] colors = new String[symbols.size()];
        for(int i=0; i< symbols.size(); i++){
            colors[i] = symbols.get(i).getColor();
        }
        ok = true;
        return colors;
    }
    
    /**
     * Returns how many distinct symbols are visible in the settings
     * @return quantity of distinct visible colors.
     */
    public int distinctSymbols(){
        //HashSet es igual que un arraylist pero no acepta repetidos
        HashSet<String> distintos = new HashSet<String>(); 
        for(Wheel w : wheels){
            Symbol s = w.visibleSymbol();
            if(s != null){
                distintos.add(s.getColor());
            }
        }
        ok = true;
        return distintos.size();
    }
    
    /**
     * Return the visible color of all the wheels from left to right
     * @return arraylist of the colors of each wheel
     */
    public String[] configuration(){
        String[] config = new String[wheels.size()];
        for(int i = 0; i < wheels.size(); i++){
            Symbol s = wheels.get(i).visibleSymbol();
            config[i] = (s== null) ? null : s.getColor();
        }
        ok = true;
        return config;
    }
    
    /**
     * Indicates if the actual setting is the winner
     * @return true if theres jackpot
     */
    public boolean isJackpot(){
        ok = true;
        if(wheels.isEmpty()){
            return false;
        }
        return distinctSymbols() == 1;
    }
    
    /**
     * Makes Visible the simulator
     */
    public void makeVisible(){
        isVisible = true;
        body.makeVisible();
        for(Wheel w : wheels){
            w.makeVisible();
        }
        refresh();
        ok = true;
    }
    
    /**
     * Makes invisible the simulator
     */
    public void makeInvisible(){
        for(Wheel w : wheels){
            w.makeInvisible();
        }
        body.makeInvisible();
        isVisible = false;
        ok = true;
    }
    
    /**
     * Finish the simulator
     */
    public void exit(){
        System.exit(0);
    }
    
    /**
     * Indicates if the last action was made successfully
     * @return trie if the las operation was successfull
     */
    public boolean ok(){
        return ok;
    }
    
    public void lock(int wheel){
        if(wheels.isEmpty()){
            ok = false;
            report("No hay ruedas para fijar.");
            return;
        }
        int max = wheels.size();
        int i = adjust(wheel, max);
        wheels.get(i - 1).lock();
        ok = true;
    }
    
    public void unlock(int wheel){
        if(wheels.isEmpty()){
            ok = false;
            report("No hay ruedas para soltar.");
            return;
        }
        int max = wheels.size();
        int i = adjust(wheel, max);
        wheels.get(i - 1).unlock();
        ok = true;
    }
    
    public void swap(int wheel1, int wheel2){
        if(wheels.isEmpty()){
            ok = false;
            report("No hay ruedas para intercambiar.");
            return;
        }
        int max = wheels.size();
        int i = adjust(wheel1, max);
        int j = adjust(wheel2, max);
        Wheel temp = wheels.get(i - 1);
        wheels.set(i - 1, wheels.get(j - 1));
        wheels.set(j - 1, temp);
        refresh();
        ok = true;
    }
    
    public void spin(int wheel, int steps){
        if(wheels.isEmpty()){
            ok = false;
            report("No hay ruedas para girar.");
            return;
        }
        int max = wheels.size();
        int i = adjust(wheel, max);
        if(wheels.get(i - 1).isLocked()){
            ok = false;
            report("La rueda " + i + " esta fija.");
            return;
        }
        wheels.get(i-1).spin(steps);
        refresh();
        ok = true;
    }
    
    public void spin(String[] setSymbols){
        if(setSymbols == null || wheels.isEmpty()){
            ok = false;
            report("No se puede fijar la configuracion");
            return;
        }
        if(setSymbols.length != wheels.size()){
            ok = false;
            report("La configuracion no coincide con el numero de ruedas");
            return;
        }
        for(String color : setSymbols){
            if(findSymbol(color) == null){
                ok = false;
                report("El color " + color + " no existe");
                return;
            }
        }
        for(Wheel w : wheels){
            if(w.isLocked()){
                ok = false;
                report("Hay una rueda fija, no se puede fijar la configuracion");
                return;
            }
        }
        for(int k = 0; k < wheels.size(); k++){
            wheels.get(k).place(findSymbol(setSymbols[k]));
        }
        refresh();
        ok = true;
    }

    /**
     * Adjust one position to the valid range
     * @param pos requested position
     * @param max allowed maximum 
     * @return the position adjusted 
     */
    private int adjust(int pos, int max){
        if(pos < 1){
            return 1;
        }
        if(pos > max){
            return max;
        }
        return pos;
    }
    
    /**
     * Search the list that shows the symbol of a given color 
     * @param color searched color
     * @return the symbol found or null if it doesm't exist
     */
    private Symbol findSymbol(String color){
        for(Symbol s : symbols){
            if(s.getColor().equalsIgnoreCase(color)){
                return s;
            }
        }
        return null;
    }
    
    private void refresh(){
        int n = wheels.size();
        if(n > 0){
            body.changeSize(120, 40 + n * 70);
        }
        for(int i = 0; i < n; i++){
            wheels.get(i).moveTo(60 + i * 70, 70);
        }
    }
    
    /**
     * Shows a message to the user, only if the machine is visible.
     * @param message text to show
     */
    private void report(String message){
        if(isVisible){
            JOptionPane.showMessageDialog(null, message);
        }
    }
}