/**
 * Un simbolo de la maquina tragamonedas.
 *
 * En este diseno el simbolo SI se dibuja a si mismo: tiene su propio
 * rectangulo (frame) que se pinta dentro de la ventana de una rueda. Como
 * cada rueda tiene sus PROPIOS objetos Symbol, un mismo color puede verse en
 * varias ruedas a la vez (cada uno es un objeto distinto, con su propio frame).
 *
 * @author Juan Sebastian Garavito Mejia
 * @author Laila Zareth Romano Guerrero
 * @version Ciclo 1
 */


public class Symbol{
    private String color;
    private Rectangle frame; //el cuadro de color que se dibuja
    private int x, y; 
    private boolean isVisible;

    /**
     * Create a symbol identified by a color.
     * @param color : CSS standard color name.
     */
    public Symbol(String color){
        this.color = color;
        frame = new Rectangle(); //por defecto se crea en (70,15)
        frame.changeColor(color);
        frame.changeSize(40,40);
        x= 70; y=15;
        isVisible = false;
    }

    /**
     * Returns the color that identifies this symbol.
     * @return the CSS color name
     */
    public String getColor(){
        return color;
    }

    /**
     * Two symbols are equal if they have the same color.
     * @param o the object to compare.
     * @return true if o is a Symbol of the same color.
     */
    public boolean equals(Object o){
        if( !(o instanceof Symbol)){
            return false;
        }
        return color.equalsIgnoreCase(((Symbol)o).color);
    }

    /**
     * Positions the symbol's frame at an absolute
     *  position on the canvas.
     * @param nx new horizontal position.
     * @param ny new vertical position.
     */
    public void moveTo(int nx, int ny){
        frame.moveHorizontal(nx - x);
        frame.moveVertical(ny -y);
        x= nx ; y=ny;
    }

    /**
     * Draws the symbols frame, makes it visible.
     */
    public void frame(){
        isVisible = true;
        frame.makeVisible();
    }

    /**
     * Hides the symbol frame
     */
    public void makeInvisible(){
        frame.makeInvisible();
        isVisible = false;
    }

}
