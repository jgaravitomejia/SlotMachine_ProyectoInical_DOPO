import java.util.ArrayList;
/**
 * One wheel of the slot machine.
 * 
 * @author GaravitoM-RomanoG
 * @version Cicle 1
 */
public class Wheel
{
    private ArrayList<Symbol> reel;
    private int offset;
    private Rectangle window;
    private int x, y;
    private boolean isVisible;
    private Symbol shown;
    private boolean locked;
    
    /**
     * Create a wheel with their own list of symbols
     * @param reel symbols of this wheel
     * @param x horizontal position of the window
     * @param y vertical position of the window
     */
    public Wheel(ArrayList<Symbol> reel, int x, int y){
        this.reel = reel;
        offset = 0;
        window = new Rectangle();
        window.changeColor("white");
        window.changeSize(60, 60);
        this.x = 70;
        this.y = 15;
        isVisible = false;
        locked = false;
        shown = null;
        moveTo(x, y);
    }
    
    /**
     * Spin the wheel one position
     */
    public void spin(){
        if(locked){
            return;
        }
        if(!reel.isEmpty()){
            offset = offset + 1;
            normalize();
        }
        draw();
    }
    
    /**
     * Spin the wheel several times
     * @param steps number of steps to spin
     */
    public void spin(int steps){
        if(locked || reel.isEmpty()){
            return;
        }
        int direccion = (steps >= 0) ? 1 : -1;
        int count = Math.abs(steps);
        for(int k = 0; k < count; k++){
            offset = offset + direccion;
            normalize();
            draw();
        }
    }
    
    /**
     * Returns the visible symbol of the wheel
     * @return the visible symbol or null if the wheel don´t have symbols
     */
    public Symbol visibleSymbol(){
        if(reel.isEmpty()){
            return null;
        }
        return reel.get(offset);
    }
    
    /**
     * Force the the wheel to show a symbol given
     * @param symbol symbol to make visible
     */
    public void place(Symbol symbol){
        int i = reel.indexOf(symbol);
        if(i >= 0){
            offset = i;
        }
        draw();
    }
    
    /**
     * Add a custom symbol to the wheel at a given index
     * @param index index where to insert
     * @param color color CSS of the new symbol
     */
    public void addSymbol(int index, String color){
        reel.add(index, new Symbol(color));
        normalize();
        draw();
    }
    
    /**
     * Deletes the symbol of the given color form the wheel
     * @param color color CSS to delete
     */
    public void delSymbol(String color){
        Symbol visible = visibleSymbol();
        reel.remove(new Symbol(color));
        if (visible != null && visible.getColor().equalsIgnoreCase(color) && shown != null){
            shown.makeInvisible();
            shown = null;
        }
        normalize();
        draw();
    }
    
    /**
     * Relocate the wheel to a position on the canvas
     * @param nx new horizontal position of the window
     * @oaram ny new vertical position of the window
     */
    public void moveTo(int nx, int ny){
        window.moveHorizontal(nx - x);
        window.moveVertical(ny - y);
        x = nx;
        y = ny;
        draw();
    }
    
    /**
     * Makes the wheel visible
     */
    public void makeVisible(){
        isVisible = true;
        window.makeVisible();
        draw();
    }
    
    /**
     * Makes the wheel invisible
     */
    public void makeInvisible(){
        if(shown != null){
            shown.makeInvisible();
        }
        window.makeInvisible();
        shown = null;
        isVisible = false;
    }
    
    public void lock(){
        locked = true;
    }
    
    public void unlock(){
        locked = false;
    }
    
    public boolean isLocked(){
        return locked;
    }
    
    /**
     * Adjust the offset to the valid range of the symbol's list
     */
    private void normalize(){
        if(reel.isEmpty()){
            offset = 0;
            return;
        }
        offset = ((offset % reel.size()) + reel.size()) % reel.size();
    }
    
    /**
     * Fraws the symbol inside a new window
     */
    private void draw(){
        if(!isVisible){
            return;
        }
        Symbol s = visibleSymbol();
        if(shown != null && shown != s){
            shown.makeInvisible();
        }
        if(s != null){
            s.moveTo(x + 10, y + 10);
            s.frame();
        }
        shown = s;
    }
}