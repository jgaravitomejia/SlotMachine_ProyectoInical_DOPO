import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class SlotMachineTest.
 *
 * @author  GaravitoM-RomanoG
 * @version Ciclo 2
 */
public class SlotMachineC2Test
{
    private SlotMachine machine;

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @BeforeEach
    public void setUp()
    {
        machine = new SlotMachine();
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @AfterEach
    public void tearDown()
    {
    }
    
    //Crea una slotmachine con 3 ruedas y 3 simbolos (red, blue, green)
    private void baseThreeAndThree(){
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        machine.addSymbol(3, "green");
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addWheel(3);
    }
    
    @Test
    public void shouldStartEmptyAndOk(){
        assertTrue(machine.ok());
        assertEquals(0, machine.symbols().length);
        assertEquals(0, machine.configuration().length);
    }
    
    @Test
    public void shouldAddSymbolsInOrder(){
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        assertArrayEquals(new String[]{"red", "blue"}, machine.symbols());
        assertTrue(machine.ok());
    }
    
    @Test
    public void ShouldClampPositionWhenAddingSymbols(){
        machine.addSymbol(1, "red");
        machine.addSymbol(99, "blue"); //mayor posicion, va al final
        machine.addSymbol(-5, "green"); //menor posicion, va al inicio
        assertArrayEquals(new String[]{"green", "red", "blue"}, machine.symbols());
    }
    
    @Test
    public void shouldNotDeleteSymbolThatDoesNotExist(){
        machine.addSymbol(1, "red");
        machine.delSymbol("cyan");
        assertFalse(machine.ok());
        assertArrayEquals(new String[]{"red"}, machine.symbols());
    }
    
    @Test
    public void shouldShareSymbolsWithAllWheels(){
        baseThreeAndThree();
        // todas las ruedas empiezan mostrando el primer simbolo
        assertArrayEquals(new String[]{"red", "red", "red"}, machine.configuration());
    }
    
    @Test
    public void shouldNotDeleteWheelWhenEmpty(){
        machine.delWheel(1);
        assertFalse(machine.ok());
    }
    
    @Test
    public void shouldSpinOneWheel(){
        baseThreeAndThree();
        machine.spin(2); //rueda 2 avanza a blue
        assertArrayEquals(new String[]{"red", "blue", "red"}, machine.configuration());
        assertTrue(machine.ok());
    }
    
    @Test
    public void shouldNotSpinWhenNoWheels(){
        machine.spin(1); //no hya rueda
        assertFalse(machine.ok());
    }
    
    @Test
    public void shouldPlaceSymbolInWheel(){
        baseThreeAndThree();
        machine.placeSymbol(1, "green");
        assertEquals("green", machine.configuration()[0]);
        assertTrue(machine.ok());
    }
    
    @Test 
    public void shouldNotPlaceSymbolThatDoesNotExist(){
        baseThreeAndThree();
        machine.placeSymbol(1, "cyan"); //color inexistente
        assertFalse(machine.ok());
    }
    
    @Test 
    public void shouldDetectJackpot(){
        baseThreeAndThree(); //las 3 ruedas en red
        assertTrue(machine.isJackpot());
        assertEquals(1, machine.distinctSymbols());
    }
    
    @Test
    public void shouldNotBeJackpotWithDifferentSymbols(){
        baseThreeAndThree();
        machine.spin(2);
        assertFalse(machine.isJackpot());
        assertEquals(2, machine.distinctSymbols());
    }
    
    @Test
    public void shouldSwapTwoWheels(){
        baseThreeAndThree();
        machine.placeSymbol(1, "red");
        machine.placeSymbol(3, "green");
        machine.swap(1, 3);
        assertEquals("green", machine.configuration()[0]);
        assertEquals("red", machine.configuration()[2]);
    }
    
    @Test 
    public void shouldNotSwapTwoWheels(){
        machine.swap(1, 2);
        assertFalse(machine.ok());
    }
    
    @Test
    public void shouldNotSpinLockedWheel(){
        baseThreeAndThree();
        machine.lock(1);
        machine.spin(1);
        assertFalse(machine.ok());
        assertEquals("red", machine.configuration()[0]);
    }
    
    @Test public void shouldSpinAgainAfterUnlock(){
        baseThreeAndThree();
        machine.lock(1);
        machine.unlock(1);
        machine.spin(1);
        assertTrue(machine.ok());
        assertEquals("blue", machine.configuration()[0]);
    }
    
    @Test
    public void shouldSpinSeveralSteps(){
        baseThreeAndThree();
        machine.spin(1, 2);
        assertEquals("green", machine.configuration()[0]);
    }
    
    @Test
    public void shouldWrapAroundWhenSpinningManySteps(){
        baseThreeAndThree();
        machine.spin(1, 3);
        assertEquals("red", machine.configuration()[0]);
    }
    
    @Test
    public void shouldSetGivenConfiguration(){
        baseThreeAndThree();
        machine.spin(new String[]{"green", "red", "blue"});
        assertArrayEquals(new String[]{"green", "red", "blue"}, machine.configuration());
        assertTrue(machine.ok());
    }
    
    @Test
    public void shouldNotSetConfigurationWithWrongLength(){
        baseThreeAndThree();
        machine.spin(new String[]{"blue", "blue"});
        assertFalse(machine.ok());
        assertArrayEquals(new String[]{"red", "red", "red"}, machine.configuration());
    }
    
    @Test
    public void shouldNotSetConfigurationWithInvalidColor(){
        baseThreeAndThree();
        machine.spin(new String[]{"red", "cyan", "green"}); //cyan no existe
        assertFalse(machine.ok());
        assertArrayEquals(new String[]{"red", "red", "red"}, machine.configuration());
    }
    
}