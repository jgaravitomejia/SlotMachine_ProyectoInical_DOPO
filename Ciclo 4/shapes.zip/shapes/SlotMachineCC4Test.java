import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Se verifican dos comportamientos del enunciado que todos deben cumplir:
 *   - una rueda lefty, al girar, copia el estado de su vecina de la izquierda.
 *   - una rueda rebel no se deja eliminar.
 *
 * @author Garavitom-RomanoG
 * @version Ciclo 4
 */
public class SlotMachineCC4Test
{
    private SlotMachine machine;

    /**
     * Se ejecuta antes de cada prueba: crea una maquina vacia.
     */
    @BeforeEach
    public void setUp()
    {
        machine = new SlotMachine();
    }

    /**
     * Se ejecuta despues de cada prueba.
     */
    @AfterEach
    public void tearDown()
    {
    }

    /**
     * Una rueda lefty, al girar, debe quedar mostrando el mismo simbolo que la
     * rueda de su izquierda (copia su estado).
     */
    @Test
    public void leftyWheelShouldCopyItsLeftNeighbor()
    {
        machine.addSymbol("normal", 1, "red");
        machine.addSymbol("normal", 2, "blue");
        machine.addSymbol("normal", 3, "green");
        machine.addWheel("normal", 1);   // rueda 1: normal (la vecina de la izquierda)
        machine.addWheel("lefty", 2);    // rueda 2: lefty
        // dejamos las dos ruedas en colores distintos
        machine.placeSymbol(1, "green");
        machine.placeSymbol(2, "red");
        // al girar la lefty, debe copiar el color de la rueda 1
        machine.spin(2, 1);
        String[] config = machine.configuration();
        assertEquals(config[0], config[1]);   
        // la lefty quedo igual a su vecina
    }

    /**
     * Una rueda rebel no se deja eliminar: delWheel no debe tener exito y la rueda
     * debe seguir estando.
     */
    @Test
    public void rebelWheelShouldNotBeDeleted()
    {
        machine.addSymbol("normal", 1, "red");
        machine.addSymbol("normal", 2, "blue");
        machine.addWheel("rebel", 1);
        int before = machine.configuration().length;
        machine.delWheel(1);
        assertFalse(machine.ok());                             
        // la operacion no tuvo exito
        assertEquals(before, machine.configuration().length);  
        // la rueda sigue ahi
    }
}