import java.util.ArrayList;
/**
 * Rebel wheel: spins just like a normal wheel but CANNOT be locked,
 * swapped, or removed. It achieves this by redefining the permissions that
 * Wheel sets to true by default; the machine checks these permissions before acting.
 *
 * @author Garavitom-RomanoG
 * @version Cycle 4
 */
public class RebelWheel extends Wheel{
    /**
     * Creates a reel with its own list of symbols.
     *
     * @param reel symbols for this reel.
     * @param x horizontal position of the window.
     * @param y vertical position of the window.
     */
    public RebelWheel(ArrayList<Symbol> reel, int x, int y){
        super(reel, x, y);
    }
    
    /**
     * The the rebel wheel type.
     *
     * @return "rebel".
     */
    public String type(){
        return "rebel";
    }
    
    /**
     * A rebel wheel refuses to be locked.
     *
     * @return false always.
     */
    @Override
    public boolean allowsLock(){
        return false;
    }
    
    /**
     * A rebel wheel cannot be swapped.
     *
     * @return false always.
     */
    @Override
    public boolean allowsSwap(){
        return false;
    }
    
    /**
     * A rebel wheel cannot be deleted.
     *
     * @return false always.
     */
    @Override
    public boolean allowsDelete(){
        return false;
    }
}
