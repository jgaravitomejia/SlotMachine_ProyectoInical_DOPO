import java.util.ArrayList;
/**
 * Standard wheel: the typical wheel. It rotates, advancing by its own offset, 
 * and can be locked, swapped, and removed. It adds no new behavior, it reuses
 * everything inherited from Wheel.
 *
 * @author Garavitom-RomanoGs
 * @version Cycle 4
 */
public class NormalWheel extends Wheel{
    /**
     * Creates a standard reel with its own list of symbols.
     *
     * @param reel the symbols for this reel.
     * @param x the horizontal position of the window.
     * @param y the vertical position of the window.
     */
    public NormalWheel(ArrayList<Symbol> reel, int x, int y){
        super(reel, x, y); //usa el constructor de Wheel
    }
    
    /**
     * The normal wheel type.
     *
     * @return "normal".
     */
    public String type(){
        return "normal";
    }
    
}
