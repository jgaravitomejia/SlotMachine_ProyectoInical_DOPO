import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;

/**
 *Cycle 4 unit tests: wheel types (normal, Lefty, Rebel) and symbol 
 *types (normal, ephemeral, shy, growing).
 *
 * @author Garavitom-RomanoG
 * @version Ciclo 4
 */
public class SlotMachineC4Test{
    private SlotMachine contest;

    /**
     * Constructs a list of normal symbols with the given colors.
     * 
     * @param colors the colors of the symbols.
     * @return the list of symbols.
     */
    private ArrayList<Symbol> reel(String[] colors){
        ArrayList<Symbol> r = new ArrayList<Symbol>();
        for(String c : colors){
            r.add(new NormalSymbol(c));
        }
        return r;
    }

    
    @BeforeEach
    public void setUp(){
        contest = new SlotMachine();
    }

    
    @AfterEach
    public void tearDown(){
    }

    //  Tipos de rueda    

    @Test
    public void shouldReportWheelTypes(){
        assertEquals("normal",new NormalWheel(reel(new String[]{"red","blue"}), 0, 0).type());
        assertEquals("lefty",new LeftyWheel(reel(new String[]{"red","blue"}), 0, 0).type());
        assertEquals("rebel",new RebelWheel(reel(new String[]{"red","blue"}), 0, 0).type());
    }

    @Test
    public void normalWheelShouldAllowLockSwapAndDelete(){
        Wheel w = new NormalWheel(reel(new String[]{"red","blue"}), 0, 0);
        assertTrue(w.allowsLock());
        assertTrue(w.allowsSwap());
        assertTrue(w.allowsDelete());
    }

    @Test
    public void rebelWheelShouldNotAllowLockSwapOrDelete(){
        Wheel w = new RebelWheel(reel(new String[]{"red","blue"}), 0, 0);
        assertFalse(w.allowsLock());
        assertFalse(w.allowsSwap());
        assertFalse(w.allowsDelete());
    }

    @Test
    public void leftyWheelShouldCopyLeftNeighborWhenSpun(){
        // la vecina de la izquierda queda en la posicion 2
        Wheel left = new NormalWheel(reel(new String[]{"red","blue","green"}), 0, 0);
        left.spin(2);
        // la lefty, al girar, debe copiar esa misma posicion
        LeftyWheel lefty =  new LeftyWheel(reel(new String[]{"red","blue","green"}), 0, 0);
        lefty.setLeftNeighbor(left);
        lefty.spin(1);
        assertEquals(2, lefty.currentIndex());
    }

    @Test
    public void leftyWheelWithoutNeighborShouldSpinNormally(){
        // sin vecina a la izquierda, lefty se comporta como una rueda normal
        LeftyWheel lefty = new LeftyWheel(reel(new String[]{"red","blue","green"}), 0, 0);
        lefty.spin(1);
        assertEquals(1, lefty.currentIndex());
    }

    
    //  La maquina respeta a la rueda rebel

    @Test
    public void shouldLockNormalWheel(){
        contest.addSymbol(1, "red");
        contest.addSymbol(2, "blue");
        contest.addWheel("normal", 1);
        contest.lock(1);
        assertTrue(contest.ok()); // una rueda normal si se bloquea
    }

    @Test
    public void shouldNotLockRebelWheel(){
        contest.addSymbol(1, "red");
        contest.addSymbol(2, "blue");
        contest.addWheel("rebel", 1);
        contest.lock(1);
        assertFalse(contest.ok());              // una rueda rebel no se bloquea
    }

    @Test
    public void shouldNotDeleteRebelWheel(){
        contest.addSymbol(1, "red");
        contest.addSymbol(2, "blue");
        contest.addWheel("rebel", 1);
        int before = contest.configuration().length;
        contest.delWheel(1);
        assertFalse(contest.ok());              // la operacion no tuvo exito
        assertEquals(before, contest.configuration().length);  // sigue estando la rueda
    }

    //  Tipos de simbolo, la fabrica

    @Test
    public void shouldCreateEachSymbolType(){
        assertEquals("normal",    Symbol.create("normal", "red").type());
        assertEquals("ephemeral", Symbol.create("ephemeral", "red").type());
        assertEquals("shy",       Symbol.create("shy", "red").type());
        assertEquals("growing",   Symbol.create("growing", "red").type());
    }

    @Test
    public void unknownSymbolTypeShouldBecomeNormal(){
        // un tipo que no existe se trata como normal
        assertEquals("normal", Symbol.create("xyz", "red").type());
    }

    @Test
    public void specialSymbolsShouldSurviveManySelections(){
        // encoger/crecer/esconderse no debe fallar ni pasarse de sus limites
        Symbol e = new EphemeralSymbol("red");
        Symbol g = new GrowingSymbol("red");
        Symbol s = new ShySymbol("red");
        for(int k = 0; k < 50; k++){
            e.onSelected();
            g.onSelected();
            s.onSelected();
        }
        assertEquals("ephemeral", e.type());
        assertEquals("growing", g.type());
        assertEquals("shy", s.type());
    }
}