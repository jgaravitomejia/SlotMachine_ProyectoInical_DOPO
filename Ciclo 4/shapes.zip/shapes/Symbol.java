/**
 * Slot machine symbol.
 *
 * In Cycle 4, this class becomes ABSTRACT: it is no longer instantiated
 * directly, but rather through its subclasses. It encapsulates everything
 * common to any symbol: its color, its bounding box (frame)
 * that gets drawn, its position, and how it is shown or hidden.
 *
 * Design decisions: 
 *  - type() is abstract: each subclass declares its own type.
 *  - onSelected() is called when the wheel leaves this symbol visible after a spin.
 *    By default, it does nothing (for NormalSymbol); EphemeralSymbol and ShySymbol override it.
 *  - create() is a static factory method: it centralizes subtype creation,
 *    ensuring that both SlotMachine and Wheel create symbols in the same way.
 *
 * @author Garavitom-RomanoG
 * @version Cycle 4
 */
public abstract class Symbol
{
    protected String color;
    protected Rectangle frame;   //el cuadro de color que se dibuja
    protected int x, y;
    protected boolean isVisible;

    /**
     * Creates a symbol identified by a color.
     * 
     * @param color Standard CSS color name.
     */
    public Symbol(String color){
        this.color = color;
        frame = new Rectangle();   // por defecto se crea en (70,15)
        frame.changeColor(color);
        frame.changeSize(40, 40);
        x = 70; y = 15;
        isVisible = false;
    }

    /**
     * Factory: creates a symbol of the requested type.
     * Valid types are normal, ephemeral, shy. Any other value is
     * treated as normal.
     * 
     * @param type the type of symbol to create.
     * @param color the CSS color of the symbol.
     * @return the created symbol; if the type is not recognized, a NormalSymbol.
     */
    public static Symbol create(String type, String color){
        if(type != null && type.equalsIgnoreCase("ephemeral")){
            return new EphemeralSymbol(color);
        }
        if(type != null && type.equalsIgnoreCase("shy")){
            return new ShySymbol(color);
        }
        if(type != null && type.equalsIgnoreCase("growing")){
            return new GrowingSymbol(color);
        }
        return new NormalSymbol(color);   
        // por defecto, simbolo normal
    }

    /**
     * Returns the symbol type ("normal", "ephemeral", "shy").
     * @return The name of the symbol type.
     */
    public abstract String type();

    /**
     * Called when the wheel leaves this symbol selected (visible after a
     * spin). By default, it does nothing; subclasses with special
     * behavior (ephemeral, shy) override it.
     */
    public void onSelected(){
        //comportamiento por defecto,solo ephemeral y shy lo redefinen
    }

    /**
     * Returns the color that identifies this symbol.
     * @return the CSS color name.
     */
    public String getColor(){
        return color;
    }

    /**
     * Two symbols are equal if they have the same color.
     * 
     * @param o the object to compare.
     * @return true if o is a Symbol of the same color.
     */
    public boolean equals(Object o){
        if( !(o instanceof Symbol)){
            return false;
        }
        return color.equalsIgnoreCase(((Symbol)o).color);
    }

    /**
     * Positions the symbol's frame at an absolute position on the canvas
     * 
     * @param nx new horizontal position.
     * @param ny new vertical position.
     */
    public void moveTo(int nx, int ny){
        frame.moveHorizontal(nx - x);
        frame.moveVertical(ny - y);
        x = nx; y = ny;
    }

    /**
     * Draws the symbol's frame and makes it visible.
     */
    public void frame(){
        isVisible = true;
        frame.makeVisible();
    }

    /**
     * Hides the symbol's frame.
     */
    public void makeInvisible(){
        frame.makeInvisible();
        isVisible = false;
    }
}