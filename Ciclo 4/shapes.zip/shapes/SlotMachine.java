import java.util.ArrayList;
import java.util.HashSet;
import javax.swing.JOptionPane;
import java.util.Random; 
/**
 * SlotMachine is the controler. Mantains a list that shows of symbols that define which color 
 * exists and in which order.
 * Each wheel haves their own symbols, so when one symbol is added or eliminated, slotmachine 
 * duplicates the change in all the wheels so al the wheels have the same changes (same symbols
 * in the same ordre)
 * 
 * @author Garavitom-RomanoG
 * @version Cicle 1
 */
public class SlotMachine{
    
    private ArrayList<Wheel> wheels;
    private ArrayList<Symbol> symbols;
    private Rectangle body;
    private boolean isVisible;
    private boolean ok;
    /**
     * Create the SlotMachine empty
     */
    public SlotMachine(){
        symbols = new ArrayList<Symbol>();
        wheels = new ArrayList<Wheel>();
        //el cuerpo se construye a si mismo con posicion, tamañp y color los pone rectangle
        body = new Rectangle(40,40,150,120,"gray");
        isVisible = false;
        ok = true;
    }
    
    /**
     * Distinct CSS color palettes for initializing a machine of size n.
     * These are valid CSS standard names (recognized by the extended Canvas).
     */
    private static final String[] PALETTE = {
        "red","blue","green","gold","orange","purple","cyan","magenta","brown","pink",
        "teal","navy","olive","maroon","lime","coral","salmon","indigo","violet",
        "turquoise","crimson","chocolate","tomato","orchid","khaki","plum","sienna","tan",
        "skyblue","seagreen","hotpink","darkred","darkblue","darkgreen","darkorange",
        "darkviolet","deeppink","firebrick","forestgreen","goldenrod","steelblue",
        "slateblue","royalblue","mediumblue","midnightblue","darkcyan","darkmagenta",
        "darkkhaki","darkolivegreen","dodgerblue"
    };
     // 50, para que sean exactos desde n hasta 50 como nos da la maraton
    /**
     * Create a machine with n wheels and n symbols, initialized randomly.
     * @param n number of reels and symbols
     */
    public SlotMachine(int n){
        this(); //reutiliza el constructor vacio
        if(n<1){
            ok = false; 
            return;
        }
        //maximo puede hacer 50, tanto como los colores permitidos
        if(n> PALETTE.length){
            n = PALETTE.length;
        }
        //n simbolos distintos
        for(int k=0; k<n; k++){
            addSymbol(k+1, PALETTE[k]);
        }
        //n ruedas
        for(int k=0; k<n; k++){
            addWheel(k+1);
        }
        spin(); //configuracion al azar
        ok = true;
        
    }
   
    
    /**
     * Add a wheel in the indicated position. Por defecto crea una rueda "normal".
     * @param pos position of the wheel that is inserted
     */
    public void addWheel(int pos){
        //reutiliza la version con tipo: una rueda sin tipo es una rueda normal
        addWheel("normal", pos);
    }

    /**
     * Add a wheel of the given type in the indicated position.
     * Los tipos validos son: "normal", "lefty", "rebel". Cualquier otro valor se
     * trata como "normal".
     * @param type tipo de rueda a crear.
     * @param pos position of the wheel that is inserted
     */
    public void addWheel(String type, int pos){
        int max = wheels.size() + 1;
        int i = adjust(pos, max);
        ArrayList<Symbol> propios = new ArrayList<Symbol>();
        for(Symbol s : symbols){
            propios.add(Symbol.create(s.type(), s.getColor())); 
            //copia conservando el tipo
        }
        Wheel w = createWheel(type, propios);
        //fabrica la subclase segun el tipo
        wheels.add(i - 1, w);
        if (isVisible){
            w.makeVisible();
        }
        refresh();
        ok = true;
    }

    /**
     * Creates the wheel subclass corresponding to the requested type.
     * Centralizing creation here ensures that adding a new wheel type 
     * in the future requires modifying only this method.
     * 
     * @param type wheel type ("normal", "lefty", "rebel").
     * @param reel list of symbols specific to the wheel.
     * @return the created wheel; returns a NormalWheel if the 
     * type is unrecognized.
     */
    private Wheel createWheel(String type, ArrayList<Symbol> reel){
        if(type != null && type.equalsIgnoreCase("lefty")){
            return new LeftyWheel(reel, 0, 0);
        }
        if(type != null && type.equalsIgnoreCase("rebel")){
            return new RebelWheel(reel, 0, 0);
        }
        return new NormalWheel(reel, 0, 0);   
        //por defecto, rueda normal
    }
    
    /**
     * Delete the wheel in the indicated position
     * @param pos position of the wheel that will be deleted
     */
    public void delWheel(int pos){
        if (wheels.isEmpty()){
            ok = false;
            report("no hay ruedas para eliminar");
            return;
        }
        int max = wheels.size();
        int i = adjust(pos, max);
        if(!wheels.get(i - 1).allowsDelete()){   //una rueda rebel no se deja eliminar
            ok = false;
            report("La rueda " + i + " es rebelde: no se puede eliminar.");
            return;
        }
        wheels.get(i - 1).makeInvisible();
        wheels.remove(i - 1);
        refresh();
        ok = true;
    }
    
    /**
     * Add a symbol (color CSS) in the indicated position.
     * It replicates in all the wheels to keep them the same.
     * 
     * @param pos position where the symbol is inserted
     * @param color name of the color from the standard CSS
     */
        public void addSymbol(int pos, String color){
        //reutiliza la version con tipo: un simbolo sin tipo es normal
        addSymbol("normal", pos, color);
    }
    
    /**
     * Add a symbol of the given type in the indicated position.
     * Valid types are: "normal", "ephemeral", "shy". Any other value 
     * is treated as normal. It replicates in all the wheels to keep
     * them the same.
     * 
     * @param type symbol type to create.
     * @param pos position where the symbol is inserted
     * @param color name of the color from the standard CSS
     */
    public void addSymbol(String type, int pos, String color){
        ok = false; 
        int max = symbols.size() + 1;
        int i = adjust(pos, max);
        symbols.add(i - 1, Symbol.create(type, color)); 
        //fabrica el subtipo,osea, crea
        for(Wheel w : wheels){
            w.addSymbol(i - 1, type, color);
        }
        refresh();
        ok = true;
    }
    
    /**
     * Deletes the symbols of the indicated color (from the machine and all the wheels)
     * @param symbol color of the symbol that will be deleted.
     */
    public void delSymbol(String symbol){
        Symbol s = findSymbol(symbol);
        if (s == null){
            ok = false;
            report("No existe el simbolo de color "+ symbol + ".");
            return;
        }
        symbols.remove(s);
        for(Wheel w: wheels){
            w.delSymbol(symbol);
        }
        refresh();
        ok = true;
    }
    
    /**
     * Place a symbol in an specific wheel.
     * @param wheel number o f the wheel.
     * @param symbol color of the symbol to show in the wheel.
     */
    public void placeSymbol( int wheel, String symbol){
        Symbol s =  findSymbol(symbol);
        if(wheels.isEmpty() || s == null){
            ok = false;
            report("No se puede colocar el simbolo" + symbol + ".");
            return;
        }
        int max = wheels.size();
        int i = adjust(wheel, max);
        wheels.get(i-1).place(s);
        refresh();
        ok = true;
    }
    
    /**
     * Spin an specific wheel.
     * @param wheel number of the wheel
     */
    public void spin(int wheel){
        if(wheels.isEmpty()){
            ok = false;
            report("No hay ruedas para girar.");
            return;
        }
        int max = wheels.size();
        int i = adjust(wheel, max);
        if(wheels.get(i - 1).isLocked()){
            ok = false;
            report("La rueda" + i + " esta fija.");
            return;
        }
        wheels.get(i-1).spin();
        refresh();
        ok = true;
    }
    
    /**
     * It spins all the wheels, each by a random number of steps.
     * Respect fixed wheels, Wheel.spin(steps) does nothing if the wheel 
     * is locked. In invisible mode, it draws nothing.
     */
    public void spin(){
        Random rnd = new Random();
        //bound limite superior, numero de simbolos = posiciones posibles
        int bound = symbols.size(); 
        for(Wheel w : wheels){
            int steps;
            if(bound >0){
                steps = rnd.nextInt(bound) + 1; //un giro al azar entre 1 y bound
            }else{
                steps = 0; //si no hay un simbolos, no gira
            }
            w.spin(steps); //cada rueda gira al azar
        }
        refresh();
        ok=true;
    }
    
    /**
     * Returns the color of the symbols in the machine, in order from 1
     * @return ArrayList with the colors of the symbols.
     */
    public String[] symbols(){
        String[] colors = new String[symbols.size()];
        for(int i=0; i< symbols.size(); i++){
            colors[i] = symbols.get(i).getColor();
        }
        ok = true;
        return colors;
    }
    
    /**
     * Returns how many distinct symbols are visible in the settings
     * @return quantity of distinct visible colors.
     */
    public int distinctSymbols(){
        //HashSet es igual que un arraylist pero no acepta repetidos
        HashSet<String> distintos = new HashSet<String>(); 
        for(Wheel w : wheels){
            Symbol s = w.visibleSymbol();
            if(s != null){
                distintos.add(s.getColor());
            }
        }
        ok = true;
        return distintos.size();
    }
    
    /**
     * Return the visible color of all the wheels from left to right
     * @return arraylist of the colors of each wheel
     */
    public String[] configuration(){
        ok  = false;
        String[] config = new String[wheels.size()];
        for(int i = 0; i < wheels.size(); i++){
            Symbol s = wheels.get(i).visibleSymbol();
            if(s == null){                 //la rueda no tiene simbolo visible
                config[i] = null;
            }else{                         //guarda el color del simbolo visible
                config[i] = s.getColor();
            }
        }
        ok = true;
        return config;
    }
    
    /**
     * Indicates if the actual setting is the winner
     * @return true if theres jackpot
     */
    public boolean isJackpot(){
        ok = true;
        if(wheels.isEmpty()){
            return false;
        }
        return distinctSymbols() == 1;
    }
    
    /**
     * Makes Visible the simulator
     */
    public void makeVisible(){
        ok =  false;
        isVisible = true;
        body.makeVisible();
        for(Wheel w : wheels){
            w.makeVisible();
        }
        refresh();
        ok = true;
    }
    
    /**
     * Makes invisible the simulator
     */
    public void makeInvisible(){
        ok = false;
        for(Wheel w : wheels){
            w.makeInvisible();
        }
        body.makeInvisible();
        isVisible = false;
        ok = true;
    }
    
    /**
     * Finish the simulator
     */
    public void exit(){
        System.exit(0); //0 sin errores
    }
    
    /**
     * Indicates if the last action was made successfully
     * @return trie if the las operation was successfull
     */
    public boolean ok(){
        return ok;
    }
    
    /**
     * Locks (fixes) a wheel so it cannot rotate. A "rebel" wheel cannot be
     * locked.
     * 
     * @param wheel The number of the wheel to lock.
     */
    public void lock(int wheel){
        if(wheels.isEmpty()){
            ok = false;
            report("No hay ruedas para fijar.");
            return;
        }
        int max = wheels.size();
        int i = adjust(wheel, max);
        if(!wheels.get(i - 1).allowsLock()){   //una rueda rebel no se deja bloquear
            ok = false;
            report("La rueda " + i + " es rebelde: no se puede bloquear.");
            return;
        }
        wheels.get(i - 1).lock();
        ok = true;
    }
    
    /**
     * Unlocks (releases) a wheel so it can spin again.
     * 
     * @param wheel The number of the wheel to unlock.
     */
    public void unlock(int wheel){
        if(wheels.isEmpty()){
            ok = false;
            report("No hay ruedas para soltar.");
            return;
        }
        int max = wheels.size();
        int i = adjust(wheel, max);
        wheels.get(i - 1).unlock();
        ok = true;
    }
    
    /**
     * Swaps the positions of two wheels. If either of the two is a rebel, the
     * swap does not take place.
     * 
     * @param wheel1 number of the first wheel.
     * @param wheel2 number of the second wheel.
     */
    public void swap(int wheel1, int wheel2){
        if(wheels.isEmpty()){
            ok = false;
            report("No hay ruedas para intercambiar.");
            return;
        }
        int max = wheels.size();
        int i = adjust(wheel1, max);
        int j = adjust(wheel2, max);
        //si alguna de las dos ruedas es rebel, no se puede intercambiar
        if(!wheels.get(i - 1).allowsSwap() || !wheels.get(j - 1).allowsSwap()){
            ok = false;
            report("No se puede intercambiar: hay una rueda rebelde.");
            return;
        }
        Wheel temp = wheels.get(i - 1);
        wheels.set(i - 1, wheels.get(j - 1));
        wheels.set(j - 1, temp);
        refresh();
        ok = true;
    }
    
    /**
     * Rotates a specific wheel by a given number of steps. Does not rotate if the wheel is
     * locked.
     * @param wheel the number of the wheel to rotate.
     * @param steps the number of steps to rotate (positive or negative).
     */
    public void spin(int wheel, int steps){
        if(wheels.isEmpty()){
            ok = false;
            report("No hay ruedas para girar.");
            return;
        }
        int max = wheels.size();
        int i = adjust(wheel, max);
        if(wheels.get(i - 1).isLocked()){
            ok = false;
            report("La rueda " + i + " esta fija.");
            return;
        }
        wheels.get(i-1).spin(steps);
        refresh();
        ok = true;
    }
    
    /**
     * Sets the visible configuration for all reels at once: it assigns 
     * the color specified in the array to each reel. It performs no 
     * action if the array is null, if its size does not match the number
     * of reels, if a color does not exist, or if any reel is locked.
     * 
     * @param setSymbols colors to be displayed by each reel, from left to right.
     */
    public void spin(String[] setSymbols){
        if(setSymbols == null || wheels.isEmpty()){
            ok = false;
            report("No se puede fijar la configuracion");
            return;
        }
        if(setSymbols.length != wheels.size()){
            ok = false;
            report("La configuracion no coincide con el numero de ruedas");
            return;
        }
        for(String color : setSymbols){
            if(findSymbol(color) == null){
                ok = false;
                report("El color " + color + " no existe");
                return;
            }
        }
        for(Wheel w : wheels){
            if(w.isLocked()){
                ok = false;
                report("Hay una rueda fija, no se puede fijar la configuracion");
                return;
            }
        }
        for(int k = 0; k < wheels.size(); k++){
            wheels.get(k).place(findSymbol(setSymbols[k]));
        }
        refresh();
        ok = true;
    }

    /**
     * Adjust one position to the valid range
     * @param pos requested position
     * @param max allowed maximum 
     * @return the position adjusted 
     */
    private int adjust(int pos, int max){
        if(pos < 1){
            return 1;
        }
        if(pos > max){
            return max;
        }
        return pos;
    }
    
    /**
     * Search the list that shows the symbol of a given color 
     * @param color searched color
     * @return the symbol found or null if it doesm't exist
     */
    private Symbol findSymbol(String color){
        for(Symbol s : symbols){
            if(s.getColor().equalsIgnoreCase(color)){
                return s;
            }
        }
        return null;
    }
    
    /**
     * Redraws and reorganizes the machine. Adjusts the body size based 
     * on the number of reels, colors it gold if there is a jackpot 
     * (or gray otherwise), repositions each reel, and links each reel 
     * to its neighbor on the left (required by the 'lefty' reel).
     * Called after every change to keep everything up to date.
     */
    private void refresh(){
        int n = wheels.size();
        if(n > 0){
            body.changeSize(120, 40 + n * 70);
        }
        //la maquina luce diferente cuando gana 
        if(isJackpot()){
            body.changeColor("gold");
        }else{
            body.changeColor("gray");
        }
        //las ruedas se dibujas al final, para que queden encima
        for(int i = 0; i < n; i++){
            wheels.get(i).moveTo(60 + i * 70, 70);
        }
        //enlazar cada rueda con su vecina de la izquierda (solo lefty la usa).
        //se hace aqui porque refresh() corre cada vez que cambia el orden de ruedas
        for(int i = 0; i < n; i++){
            Wheel left;
            if(i > 0){                     //hay una rueda a la izquierda
                left = wheels.get(i - 1);
            }else{                         //la primera rueda no tiene vecina izquierda
                left = null;
            }
            wheels.get(i).setLeftNeighbor(left);
        }
    }
    
    /**
     * Shows a message to the user, only if the machine is visible.
     * @param message text to show
     */
    private void report(String message){
        if(isVisible){
            JOptionPane.showMessageDialog(null, message);
        }
    }
}