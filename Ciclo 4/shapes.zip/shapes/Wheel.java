import java.util.ArrayList;
/**
 * Slot machine reel.
 * In Cycle 4, this class becomes abstract.
 * @author GaravitoM-RomanoG
 * @version Cycle 4
 */

// Decisiones de diseno:
//Los atributos y los metodos de apoyo (normalize, draw) son 'protected' para
//que las subclases puedan reutilizarlos.
//type() es abstracto: obliga a cada subclase a declarar su tipo.
//allowsLock/allowsSwap/allowsDelete devuelven true por defecto (toda rueda se
//deja manipular); la rueda rebel los redefine para negarse.
//setLeftNeighbor por defecto no hace nada; solo lefty lo aprovecha.

public abstract class Wheel{
    protected ArrayList<Symbol> reel; //simbolos propios de la rueda
    protected  int offset; //indice del simbolo visible 
    protected Rectangle window; //venta, el marco grande de la rueda
    protected int x; //posicion actual de la venta en x 
    protected int y; //posicion actual de la venta en y 
    protected boolean isVisible;
    protected Symbol shown; //symolo que esta dibujado ahora
    protected boolean locked;
        
    /**
     * Create a wheel with its own list of symbols.
     * 
     * @param reel symbols for this reel (exclusive, not shared).
     * @param x horizontal position of the window.
     * @param y vertical position of the window.
     */
    public Wheel(ArrayList<Symbol> reel, int x, int y){
        this.reel = reel;
        offset = 0; 
        window = new Rectangle(); //por default en (70,15) 
        window.changeColor("white");
        window.changeSize(60,60);
        this.x= 70;
        this.y = 15;
        isVisible = false; 
        shown = null; 
        locked = false; 
        moveTo(x,y);
        
    }
    
    /**
     * Returns the wheel type ("normal", "lefty", "rebel",etc)
     * Each subclass is required to define it.
     * 
     * @return name of the wheel type.
     */
    public abstract String type();
    
    /**
     * Indicates whether this wheel can be locked. By default, yes; Rebel says no.
     *
     * @return true if it can be locked.
     */
    public boolean allowsLock(){
        return true;
    }
    /**
     * Indicates whether this wheel can be locked. 
     * By default, yes; Rebel says no.
     * @return true if it can be swapped.
     */
    public boolean allowsSwap(){
        return true;
    }
    
    /**
     * Indicates whether this wheel can be removed. By default, yes; Rebel
     * says no.
     *
     * @return true if it can be removed.
     */
    public boolean allowsDelete(){
        return true;
    }
    
    /**
     * Informs this wheel of its left-hand neighbor. By default, it does
     * nothing (a standard wheel doesn't care); 'lefty' stores it for 
     * copying.
     *
     * @param left the wheel to the left of this one, or null 
     * if none exists.
     */
    public void setLeftNeighbor(Wheel left){
        //por defecto, solo LeftWheel lo redefine
    }
    
    /**
     * Rotate the wheel one position.
     */
    public void spin(){
        spin(1);
    }
    
    /**
     * Rotates the wheel by several positions. This is the NORMAL 
     * rotation (advancing by its own offset). Subclasses with different
     * behavior (lefty) redefine this.
     * 
     * @param steps number of steps to rotate (positive or negative).
     */
    public void spin(int steps){
        if(locked || reel.isEmpty()){return; }
        int dir;
        if(steps >= 0){ //si los pasos son positivos, gira hacia adelante
            dir = 1;
        }else{ //si son negativos, gira hacia atras
            dir = -1;
        }
        int count = Math.abs(steps);
        for(int k=0; k< count; k++){
            offset = offset + dir;
            normalize();
            draw();
        }
        select(); //el simbolo que quedo visible reacciona (ephemeral/shy)
    }
    
    /**
     * Notifies the symbol that ended up visible that it was selected 
     * on the wheel,and redraws. Used by the special Symbol subclasses 
     *(ephemeral shrinks, shy hides/shows). A normal symbol does not 
     *react.
     */
    protected void select(){
        Symbol s = visibleSymbol();
        if(s != null){
            s.onSelected();
        }
        draw();
    }
    
    public void lock(){
        locked = true;
    }
    
    public void unlock(){
        locked = false;
    }
    
    public boolean isLocked(){
        return locked;
    }
    
    /**
     * Returns the index of the visible symbol (its position within
     * the reel). 
     * It is used by lefty to copy the state of the neighboring reel.
     *
     * @return index of the visible symbol.
     */
    public int currentIndex(){
        return offset;
    }
    
    /**
     * Returns the visible symbol of the wheel.
     *
     * @return the visible symbol, or null if the wheel has 
     * no symbols.
     */
    public Symbol visibleSymbol(){
        if(reel.isEmpty()){
            return null;
        }
        return reel.get(offset);
    }
    
    /**
     * Forces the wheel to display a specific symbol, based on color.
     *
     * @param symbol The symbol, compared by color, to make visible.
     */
    public void place(Symbol symbol){
        int i = reel.indexOf(symbol);
        if(i>=0){
            offset = i;
        }
        draw();
    }
    
    /**
     * Adds a custom symbol to this wheel at a given index.
     *
     * @param index index (0-based) where the symbol is to be inserted.
     * @param color CSS color of the new symbol.
     */
    public void addSymbol(int index, String color){
        //reutiliza la version con tipo, un simbolo sin tipo es normal
        addSymbol(index, "normal", color);
    }
    
    /**
     * Adds a custom symbol of the given type to this wheel at a given
     * index.
     *
     * @param index index (0-based) where the symbol is to be inserted.
     * @param type symbol type ("normal", "ephemeral", "shy").
     * @param color CSS color of the new symbol.
     */
    public void addSymbol(int index, String type, String color){
        reel.add(index, Symbol.create(type, color)); //fabrica el subtipo
        normalize();
        draw();
    }
    
    /**
     * Remove the symbol for the given color from this wheel.
     *
     * @param color CSS color to remove.
     */
    public void delSymbol(String color){
        Symbol visible = visibleSymbol();
        reel.remove(Symbol.create("normal", color)); 
        //simbolo de prueba, equals por color
        if(visible != null && visible.getColor().equalsIgnoreCase(color)
            && shown != null){
                shown.makeInvisible();
                shown = null;
            }
            normalize();
            draw();
    }
    
    /**
     * Relocates the wheel to an absolute position on the canvas.
     *
     * @param nx new horizontal position of the window.
     * @param ny new vertical position of the window.
     */
    public void moveTo(int nx, int ny){
        window.moveHorizontal(nx - x);
        window.moveVertical(ny - y);
        x= nx;
        y = ny;
        draw();
    }
    
    /**
     * It makes the wheel visible.
     */
    public void makeVisible(){
        isVisible = true;
        window.makeVisible();
        draw();
    }
    
    /**
     * It makes the wheel invisible.
     */
    public void makeInvisible(){
        if(shown != null){
            shown.makeInvisible();
        }
        window.makeInvisible();
        shown = null;
        isVisible = false;
    }
    
    /**
     * Adjust the offset to the valid range of the symbol list.
     */
    protected void normalize(){
        if(reel.isEmpty()){
            offset = 0;
            return;
        }
        offset = ((offset % reel.size())+reel.size())% reel.size();
    }
    
    /**
     * Draw the visible symbol inside the window, if the wheel is 
     * visible.
     */
    protected void draw(){
        if(!isVisible){
            return;
        }
        Symbol s= visibleSymbol();
        if(shown != null && shown != s){
            shown.makeInvisible();
        }
        if(s != null){
            s.moveTo(x+10, y+10); //centra el frame
            s.frame();
        }
        shown = s;
    }
}