/**
 * Ephemeral symbol: each time it is selected on the wheel (remaining
 * visible after a spin), its size decreases until it becomes a dot.
 *
 * @author Garavitom-RomanoG
 * @version Cycle 4
 */
public class EphemeralSymbol extends Symbol
{
    private int size;                      // tamano actual del frame
    private static final int MIN = 4;      // tamano minimo (un punto)
    private static final int STEP = 8;     // cuanto encoge cada vez que es seleccionado

    /**
     * Creates an ephemeral symbol with the given color
     * Starts at normal size.
     * 
     * @param color CSS color of the symbol.
     */
    public EphemeralSymbol(String color){
        super(color);
        size = 40;   // tamano inicial, igual al de un simbolo normal
    }

    /**
     * The type of this symbol.
     * 
     * @return "ephemeral".
     */
    public String type(){
        return "ephemeral";
    }

    /**
     * When selected, it shrinks its frame by one step, without 
     * going below the minimum size.
     */
    @Override
    public void onSelected(){
        if(size > MIN){
            size = size - STEP;
            if(size < MIN){      // no dejar que se pase del minimo
                size = MIN;
            }
            frame.changeSize(size, size);   // aplica el nuevo tamano al cuadro
        }
    }
}
