/**
 * "Shy" symbol: toggles its visibility state each time it is selected on the wheel.
 * It is visible for one turn, hidden for the next, and so on.
 *
 * To achieve this, it maintains a 'hidden' flag that toggles upon each selection
 * and redefines frame() so that, when hidden, it does not render even if the
 * wheel requests it to draw itself.
 *
 * @author Garavitom-RomanoG
 * @version Cycle 4
 */
public class ShySymbol extends Symbol
{
    private boolean hidden;   // true = este turno esta escondido (no se muestra)

    /**
     * Creates a shy symbol with the given color. It is initially visible
     * 
     * @param color CSS color of the symbol.
     */
    public ShySymbol(String color){
        super(color);
        hidden = false;   // al inicio se ve
    }

    /**
     * The type of this symbol
     * 
     * @return "shy"
     */
    public String type(){
        return "shy";
    }

    /**
     * When selected, toggles between hiding and showing.
     */
    @Override
    public void onSelected(){
        hidden = !hidden;   // cambia de estado: visible <-> invisible
    }

    /**
     * When the wheel requests to be drawn: if it is hidden, it is not displayed;
     * otherwise, it is displayed normally.
     */
    @Override
    public void frame(){
        if(hidden){
            super.makeInvisible();   // este turno esta escondido
        }else{
            super.frame();           // se muestra normal
        }
    }
}