import java.util.ArrayList;

/**
 * "Lefty" wheel: if it has a wheel to its left, rotating it does NOT advance its
 * own offset; instead, it COPIES the state (visible position) of that neighbor.
 * If there is no wheel to the left, it rotates like a normal wheel.
 *
 * The machine is informed of the neighboring wheel via setLeftNeighbor; since the
 * order of the wheels can change (addWheel, delWheel, swap), the machine
 * re-links the neighbors whenever the configuration is reorganized.
 *
 * @author Garavitom-RomanoG
 * @version Cycle 4
 */
public class LeftyWheel extends Wheel{
    private Wheel leftNeighbor; //rueda que esta a la izquierda
    
    /**
     * Creates a lefty reel with its own list of symbols.
     *
     * @param reel the symbols for this reel.
     * @param x the horizontal position of the window.
     * @param y the vertical position of the window. 
     */
    public LeftyWheel(ArrayList<Symbol> reel, int x, int y){
        super(reel, x, y);
        leftNeighbor = null; //al inicio no conoce a su veicina
    }
    
    /**
     * The lefty wheel type.
     *
     * @return "lefty".
     */
    public String type(){
        return "lefty";
    }
    /**
     * Stores the reference to the left wheel.
     *
     * @param left the neighboring wheel to the left, or null if none 
     * exists.
     */
    @Override
    public void setLeftNeighbor(Wheel left){
        this.leftNeighbor = left;
    }
    
    /**
     * Rotate the wheel. If there is a neighbor to the left, copy its 
     * state (assume the same visible position as that neighbor). 
     * If there is no neighbor, rotate like a standard one.
     *
     * @param steps steps to rotate (used only when there is no neighbor).
     */
    @Override
    public void spin(int steps){
        if(locked || reel.isEmpty()) { return; }
        if(leftNeighbor != null) {
            // copiar el estado de la vecina: ponerse en su misma posicion visible.
            // (todas las ruedas tienen los mismos simbolos en el mismo orden, asi
            //  que copiar el indice equivale a mostrar el mismo color)
            offset = leftNeighbor.currentIndex();
            normalize();
            select();   //el simbolo que quedo visible reacciona (ephemeral/shy)
        } else {
            // sin vecina a la izquierda: comportamiento normal
            super.spin(steps);
        }
    }
}

