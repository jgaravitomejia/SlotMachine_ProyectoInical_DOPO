/**
 * Growing symbol: the opposite of ephemeral. Each time it is
 * selected on the wheel (remaining visible after a spin), its
 * size increases until it reaches a maximum. This is the type 
 * we proposed.
 *
 * @author Garavitom-RomanoG
 * @version Cycle 4
 */
public class GrowingSymbol extends Symbol
{
    private int size;  // tamaño actual del frame
    private static final int MAX = 56;     
    // tamaño maximo, sin  que se pase de la ventana 60
    private static final int STEP = 8;     
    // cuanto crece cada vez que es seleccionado

    /**
     * Creates a growing symbol with the given color. Starts at normal
     * size.
     * 
     * @param color CSS color of the symbol.
     */
    public GrowingSymbol(String color){
        super(color);
        size = 40;   // tamaño inicial, igual al de un simbolo normal
    }

    /**
     * The type of this symbol, the growing symbol.
     * 
     * @return "growing".
     */
    public String type(){
        return "growing";
    }

    /**
     * When selected, it enlarges its frame by one step, 
     * without exceeding the maximum size.
     */
    @Override
    public void onSelected(){
        if(size < MAX){
            size = size + STEP;
            if(size > MAX){    //no dejar que se pase del maximo
                size = MAX;
            }
            frame.changeSize(size, size);   
            //aplica el nuevo tamaño al cuadro
        }
    }
}