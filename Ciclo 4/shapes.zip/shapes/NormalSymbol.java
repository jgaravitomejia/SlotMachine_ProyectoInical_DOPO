/**
 * Standard symbol: the usual symbol. It is displayed in its fixed color and does not change
 * when selected. It adds no behavior: it reuses all functionality from Symbol.
 *
 * @author Garavitom-RomanoG
 * @version Cycle 4
 */
public class NormalSymbol extends Symbol
{
    /**
     * Creates a standard symbol with the given color
     * 
     * @param color CSS color of the symbol
     */
    public NormalSymbol(String color){
        super(color);   // usa el constructor de Symbol
    }

    /**
     * The type of this symbol
     * 
     * @return "normal"
     */
    public String type(){
        return "normal";
    }
}