/**
 * "Shy" symbol: toggles its visibility state each time it is selected on the wheel.
 * It is visible for one turn, hidden for the next, and so on.
 *
 * To achieve this, it maintains a 'hidden' flag that toggles upon each selection
 * and redefines frame() so that, when hidden, it does not render even if the
 * wheel requests it to draw itself.
 *
 * @author Garavitom-RomanoG
 * @version Cycle 4
 */
public class Shy extends Symbol
{
    private boolean hidden;   
    //true = se encuentra escondido, no se muestra

    /**
     * Creates a shy symbol with the given color. It is initially visible
     * 
     * @param color CSS color of the symbol.
     */
    public Shy(String color){
        super(color);
        hidden = false;   //al inicio se ve
        setSize(14,40); //al agregarlo es una barra ancha y larga
    }

    /**
     * The type of this symbol
     * 
     * @return "shy"
     */
    public String type(){
        return "shy";
    }

    /**
     * When selected, toggles between hiding and showing.
     */
    @Override
    public void onSelected(){
        hidden = !hidden;   
        //cambia de estado: visible <-> invisible
        //negacion de true o false
    }

    /**
     * When the wheel requests to be drawn: if it is hidden, it is not displayed;
     * otherwise, it is displayed normally.
     */
    @Override
    public void frame(){
        if(hidden){
            super.makeInvisible();//aunque la rueda quiera dibujarlo, no lo hace
        }else{
            super.frame();//se muestra normal, usa el metodo original de symbol
        }
    }
}