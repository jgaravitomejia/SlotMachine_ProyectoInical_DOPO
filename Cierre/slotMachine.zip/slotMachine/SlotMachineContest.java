import java.util.ArrayList;

public class SlotMachineContest{

    /**
     *Solve the Slot Machine problem from the marathon: get all the reels
     *to show the same symbol (a jackpot) using only two machine
     *operations: spin(reel, steps) and distinctSymbols().
     * 
     * We cannot see the symbols; the only thing we know after each move is how many 
     * distinct colors are on the screen. Based on that, we solve it in 3 phases:
     * 
     * 1.Separate: Rotate the wheels until the n wheels show distinct symbols
     * (distinctSymbols() == n), ensuring each one ends up in a unique position.
     * 2.Learn: Using wheel 1 as a reference, determine how many steps
     * each of the other wheels needs to take to show the same symbol as wheel 1.
     * 3.Align: Rotate each wheel by those required steps all at once. Jackpot.
     * 
     *@author GaravitoM-RomanoG
     *@version Cycle 3
     */
    
    /**
     *Solves a machine of size n in invisible mode and returns the list of
     * moves {wheel, steps} made to reach the jackpot. If n is
     * outside the valid range (3 to 50), it returns an empty list.
     * 
     *@param n number of reels and symbols.
     *@return result array of actions, each action is {wheel, steps}.
     */
    public int[][] solve(int n){
        if(n <3 || n >50){
            return new int[0][]; //tamaño invalido, sin acciones
        }
        SlotMachine machine = new SlotMachine(n); //se crea invisible
        ArrayList<int[]> actions = new ArrayList<int[]>();
        resolve(machine,n, actions);
        int[][] result = new int[actions.size()][];
        for(int a=0; a<actions.size(); a++){
            result[a] = actions.get(a);
        }
        return result;
    }

    /**
     *Display the solution on screen. First, determine the result internally,
     *then animate a single rotation for each reel until the jackpot is reached, 
     *so that you don’t have to render the thousands of intermediate steps involved 
     *in the trial and error process.
     *
     * @param n number of reels and symbols.
     */
    public void simulate(int n){
        if(n <3 || n >50){
            return; //tamaño invalido, no hace nada
        }
        SlotMachine machine = new SlotMachine(n);//nace invisible
        ArrayList<int[]> actions = new ArrayList<int[]>();
        resolve(machine, n, actions); //resuelve invisible y guarda las acciones
        
        //sumamos el total de pasos girados de cada rueda
        int[] net = new int[n+1];
        for(int k=0; k< actions.size(); k++){
            int[] act = actions.get(k);//una accion= {rueda,pasos}
            int wheel = act[0];
            int steps = act[1];
            net[wheel] = net[wheel] + steps;
        }
        //devolvemos cada rueda a su posicion inicial, sigue invisible
        for(int i=1; i<=n; i++){
            if(net[i] !=0){
                machine.spin(i,-net[i]); //gira hacia atras
            }
        }
        //ahora si, mostramos y animamos un solo giro por rueda hasta llegar a jactkpot
        machine.makeVisible();
        for(int i=1; i<=n; i++){
            int move = net[i]%n; 
            //giro mas corto,lo que sobra despues de quitar las vueltas completas
            if(move<0){
                move= move+n; 
                //le sumamos el tamaño de la maquina para convertirlo en positivo
            }
            if(move != 0){
                machine.spin(i,move);
            }
        }
    }

    /**
     *Coordinate the three phases of the algorithm on the machine. Use only
     *spin(wheel, steps) and distinctSymbols().
     *   
     * @param machine the machine to be solved.
     * @param n number of reels and symbols.
     * @param actions list where actions are to be recorded, or null to not record them.
     */
    private void resolve(SlotMachine machine,int n, ArrayList<int[]> actions){
        if(n <3 || machine.distinctSymbols() ==1){
            return;
        }

        // Fase 1 - Separar: dejamos la rueda 1 quieta y movemos las demas
        // una por una hasta que distinctSymbols() aumente, indicando que
        // esa rueda ahora muestra un simbolo unico
        separateSymbols(machine, n, actions);

        // si ya es jackpot despues de separar (caso raro), salir
        if(machine.distinctSymbols() == 1){
            return;
        }

        // Fase 2 Aprender : descubrimos cuantos pasos
        // necesita cada rueda para mostrar el mismo simbolo que la rueda 1
        int[] rotation = learnToAlign(machine, n, actions);

        // Fase 3  Alinear: aplicamos los pasos aprendidos
        // cada rueda se mueve una sola vez y al final todas muestran
        // el mismo simbolo que la rueda 1: jackpot
        for(int i = 2; i <= n; i++){
            if(rotation[i] > 0){
                machine.spin(i, rotation[i]);
                takeNotes(actions, i, rotation[i]);
            }
        }
    }

    /**
     * Phase 1 - Separate. Keep wheel 1 stationary as a reference and rotate each of the other
     * wheels one step at a time until distinctSymbols() increases. This increase means
     * that the wheel has just landed in a position not occupied by any other wheel in other words,
     * it is now displaying a unique symbol. Once finished, all n wheels will be showing
     * distinct symbols. This takes at most n steps per wheel.
     * 
     * @param machine the machine.
     * @param n number of wheels/symbols.
     * @param actions list to record, or null.
     */
    private void separateSymbols(SlotMachine machine, int n, ArrayList<int[]> actions){
        for(int wheel = 2; wheel <= n; wheel++){
            for(int attempt = 0; attempt < n; attempt++){
                int distinctBefore = machine.distinctSymbols();
                machine.spin(wheel, 1);
                takeNotes(actions, wheel, 1);
                int distinctAfter = machine.distinctSymbols();
                if(distinctAfter > distinctBefore){
                    break; //esta rueda ya es unica, siguiente
                }
            }
        }
    }

    /**
     * Phase 2 - Learning. Determine how many steps each wheel requires to display
     * the same symbol as wheel 1.
     * 
     * Following Phase 1, the n wheels are in different positions. We advance
     * wheel 1 by one step at a time (step1 = 1, 2, ..., n-1). Each time it advances,
     * wheel 1 lands directly on top of exactly one other wheel (its "collision partner"),
     * leaving the position it previously occupied empty.
     * 
     * To identify this partner, we test each as-yet-unidentified wheel by
     * rotating it backward by step1 positions:
     * - If distinctSymbols() returns n, it means that wheel landed in the
     * vacant position—it is the partner. It requires (n - step1) forward steps
     * to align with wheel 1. We return it to its original position and
     * proceed to the next step1 value.
     * - If not, it landed in an occupied position (meaning there are still fewer
     * than n distinct symbols); we return it to its place and test the next wheel.
     *
     * @param machine the machine.
     * @param n number of wheels/symbols.
     * @param actions list to record, or null.
     * @return rotation[i] = steps wheel i needs to align with wheel 1.
     */
    private int[] learnToAlign(SlotMachine machine, int n, ArrayList<int[]> actions){
        int[] rotation = new int[n + 1];
        //-1 = aun no sabemos cuantos pasos necesita esta rueda
        for(int i = 2; i <= n; i++){
            rotation[i] = -1;
        }

        //movemos la rueda 1 paso a paso, de 1 hasta n-1
        for(int step1 = 1; step1 <= n - 1; step1++){
            machine.spin(1, 1);
            takeNotes(actions, 1, 1);

            //probar cada rueda no identificada
            for(int wheel = 2; wheel <= n; wheel++){
                if(rotation[wheel] != -1){
                    continue;// ya identificada, saltarla
                }

                //filtro, mover la rueda hacia abajo step1 posiciones
                machine.spin(wheel, -step1);
                takeNotes(actions, wheel, -step1);
                int distinctAfter = machine.distinctSymbols();

                if(distinctAfter == n){
                    //todos distintos de nuevo, esta rueda era la compañera
                    //de colision. Necesita (n - step1) pasos para alinearse
                    rotation[wheel] = n - step1;

                    //restaurar la rueda a su posicion
                    machine.spin(wheel, step1);
                    takeNotes(actions, wheel, step1);

                    //solo una rueda es la compañera por cada step1
                    break;
                }

                //no fue esta rueda, restauramos y probar la siguiente
                machine.spin(wheel, step1);
                takeNotes(actions, wheel, step1);
            }
        }

        //devolvemos la rueda 1 a su posicion original
        machine.spin(1, -(n - 1));
        takeNotes(actions, 1, -(n - 1));

        return rotation;
    }

    /**
     * Record a move {wheel, steps} in the list, provided the list exists, in
     * simulate, null is passed because there is no need to record moves there.
     * @param actions list of actions, or null.
     * @param i wheel number.
     * @param j steps turned.
     */
    private void takeNotes(ArrayList<int[]> actions, int i, int j){
        if(actions !=null){
            actions.add(new int[]{i,j});
        }
    }
}