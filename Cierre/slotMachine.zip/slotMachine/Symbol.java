/**
 * Slot machine symbol.
 *
 * In Cycle 4, Standard (normal) symbol and base class for the 
 * special symbols. It encapsulates everything
 * common to any symbol: its color, its bounding box (frame)
 * that gets drawn, its position, and how it is shown or hidden.
 *
 * Design decisions: 
 *  - type() returns "normal" by default, each special subclass overrides it.
 *  - onSelected() is called when the wheel leaves this symbol visible after a spin.
 *    By default it does nothing, a normal symbol does not react, Ephemeral, 
 *    Shy and Growing override it.
 *  - create() is a static factory method: it centralizes subtype creation,
 *    ensuring that both SlotMachine and Wheel create symbols in the same way.
 *
 * @author Garavitom-RomanoG
 * @version Cycle 4
 */
public class Symbol{ 
//atributos protected para que cada uno de los tipos de simbolos puedan usarlos    
    protected String color; //color que lo identifica
    protected Rectangle frame;   //cuadro de color que se dibuja en la rueda
    protected int x, y; //posicion donde esta el simbolo
    protected boolean isVisible; 
    private int width = 40;    // ancho actual del frame
    private int height = 40;   // alto actual del frame

    /**
     * Creates a symbol identified by a color.
     * 
     * @param color Standard CSS color name.
     */
    public Symbol(String color){ //metodo constructor
        this.color = color; //guarda el color en el atributo color
        frame = new Rectangle();//crea el simbolo que se va a dibujar
        frame.changeColor(color);//le dice al rectangulo de que color debe pinatrse
        setSize(40, 40);//todos los simbolos se crean con estas medidas
        x = 70; y = 15;//aparece por defecto en esta posicion 
        isVisible = false;//nace invisible
    }
    
    
     /**
     * Creates a symbol of the requested type.
     * @param type symbol type: "normal", "ephemeral", "shy", "growing".
     * Any other value is treated as "normal".
     * @param color CSS color name for the symbol.
     * @return The created symbol, normal if the type is not recognized.
     */
    public static Symbol create(String type, String color){
        //cada if verifica el tipo ignorando mayusculas 
        if(type != null && type.equalsIgnoreCase("ephemeral")){
            return new Ephemeral(color);
        }
        if(type != null && type.equalsIgnoreCase("shy")){
            return new Shy(color);
        }
        if(type != null && type.equalsIgnoreCase("growing")){
            return new Growing(color);
        }
        //tipo desconocido o null = simbolo normal
        return new Symbol(color);
    }

    /**
     * Returns the symbol type.By default "normal".
     * Each special subclass overrides it with its own type.
     * @return The name of the symbol type.
     */
    public String type(){
        return "normal"; //por defecto normal, las subclases lo redefinen
    }

    /**
     * Called when the wheel leaves this symbol selected (visible after a
     * spin). By default, it does nothing; subclasses with special
     * behavior (ephemeral, shy) override it.
     */
    public void onSelected(){
        //comportamiento por defecto,solo ephemeral y shy lo redefinen
        //cuando es un simbolo normal, ni pasa nada.Pero los otros tipos lo
        //sobreescriben, si lo necesitan 
    }

    /**
     * Returns the color that identifies this symbol.
     * @return the CSS color name.
     */
    public String getColor(){
        return color; //slotmachine necesita saber que color esta mostrando
    }

    /**
     * Two symbols are equal if they have the same color.
     * 
     * @param o the object to compare.
     * @return true if o is a Symbol of the same color.
     */
    public boolean equals(Object o){ //para detectar el jackpot
        if( !(o instanceof Symbol)){ //si es un simbolo, instanceof
            return false;
        }
        return color.equalsIgnoreCase(((Symbol)o).color);
    }
    
    /**
     * Two equal symbols, same color, must share hashCode.
     * 
     * @return hash based on the color, ignoring case.
     */
    public int hashCode(){
        return color.toLowerCase().hashCode();
    }


    /**
     * Positions the symbol's frame at an absolute position on the canvas
     * 
     * @param nx new horizontal position.
     * @param ny new vertical position.
     */
    public void moveTo(int nx, int ny){ //calcular cuanto moverlo
        
        frame.moveHorizontal(nx - x);
        frame.moveVertical(ny - y);
        x = nx; y = ny;
    }
    
    /**
     *Change the frame size and remember the current value.
     *
     *@param newHeight 
     *@param newWidth
     */
    protected void setSize(int newHeight, int newWidth){
        height = newHeight;
        width = newWidth;
        frame.changeSize(newHeight, newWidth);
    }
    
    /**
     * Center the frame within a square box with side length boxSize
     * located at (boxX, boxY).
     * 
     * @param boxX left corner of the box.
     * @param boxY upper corner of the box.
     * @param boxSize side of the frame, the window.
     */
    public void centerIn(int boxX, int boxY, int boxSize){
        int nx= boxX + (boxSize - width)/2;
        int ny= boxY + (boxSize - height)/2;
        moveTo(nx, ny);
    }

    /**
     * Draws the symbol's frame and makes it visible.
     */
    public void frame(){
        isVisible = true;
        frame.makeVisible();
    }

    /**
     * Hides the symbol's frame.
     */
    public void makeInvisible(){
        frame.makeInvisible();
        isVisible = false;
    }
}