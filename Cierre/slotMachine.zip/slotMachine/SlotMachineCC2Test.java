

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 *Shared test cases for Cycle 2, a collective creation.
 *
 * @author Garavitom-RomanoG
 * @version Cycle 2
 */
public class SlotMachineCC2Test{
    private SlotMachine machine; 
    
    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @BeforeEach
    public void setUp(){
        machine = new SlotMachine();
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @AfterEach
    public void tearDown(){
    }
    
    @Test
    public void accordingGmRgShouldSwapTwoWheels(){
        machine.addSymbol(1,"red");
        machine.addSymbol(2,"blue");
        machine.addSymbol(3,"green");
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addWheel(3);
        machine.placeSymbol(1,"red");
        machine.placeSymbol(2,"blue");
        machine.placeSymbol(3,"green");
        machine.swap(1,3); //intercambiar ruedas 1 y 3
        assertEquals("green",machine.configuration()[0]); 
        //verificamos: ahora la pos 0 (rueda 1) muestra green
        assertEquals("red",machine.configuration()[2]);
        //y la pos 2 (rueda 3) muestra red
        assertTrue(machine.ok());
    }
    
    @Test
    public void accordingGmRgShouldNotSpinLockedWheel(){
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        machine.addWheel(1);
        machine.addWheel(2);
        machine.lock(1); //fijar la rueda 1
        try{ 
            machine.spin(1); //intentar girarla
            fail("Deberia lanzar IllegalStateException");
        }catch(IllegalStateException e){
            //correcto
        }
        assertEquals("red", machine.configuration()[0]); 
        //y sigue en red, no se movió
    }
}