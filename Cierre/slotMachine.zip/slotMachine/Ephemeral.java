/**
 * Ephemeral symbol: each time it is selected on the wheel (remaining
 * visible after a spin), its size decreases until it becomes a dot.
 *
 * @author Garavitom-RomanoG
 * @version Cycle 4
 */
public class Ephemeral extends Symbol
{
    private int size; //tamaño actual del frame, en 40
    private static final int MIN = 4;//tamaño minimo, un punto
    private static final int STEP = 8;//cuanto encoge cada vez que es seleccionado

    /**
     * Creates an ephemeral symbol with the given color
     * Starts at normal size.
     * 
     * @param color CSS color of the symbol.
     */
    public Ephemeral(String color){
        super(color);
        size = 20;   //guardamos para modificar despues
        setSize(20,20); //al agregar es un cuadro pequeño
    }

    /**
     * The type of this symbol.
     * 
     * @return "ephemeral".
     */
    public String type(){
        return "ephemeral";
    }

    /**
     * When selected, it shrinks its frame by one step, without 
     * going below the minimum size.
     */
    @Override
    public void onSelected(){
        if(size > MIN){ //si aun no llega al minimo, encoge
            size = size - STEP; //decrece de 8 en 8
            if(size < MIN){      //no deja que se pase del minimo
                size = MIN; //lo sube al minimo exacto
            }
            setSize(size, size);   
            //aplica el nuevo tamano al rectangulo
        }
    }
}
