/**
 * Growing symbol: the opposite of ephemeral. Each time it is
 * selected on the wheel (remaining visible after a spin), its
 * size increases until it reaches a maximum. This is the type 
 * we proposed.
 *
 * @author Garavitom-RomanoG
 * @version Cycle 4
 */
public class Growing extends Symbol{
    private int size;  //tamaño actual del frame
    private static final int MAX = 56;     
    //tamaño maximo, sin  que se pase de la ventana 60
    private static final int STEP = 4;     
    //cuanto crece cada vez que es seleccionado

    /**
     * Creates a growing symbol with the given color. Starts at normal
     * size.
     * 
     * @param color CSS color of the symbol.
     */
    public Growing(String color){
        super(color);//llama al constructor de symbol, crea el rectangulo, tamaño 40x40
        size = 40;   //tamaño inicial, igual al de un simbolo normal
        //despues lo modifica
        setSize(40,16);//al agregar es una barra larga y angosta
    }

    /**
     * The type of this symbol, the growing symbol.
     * 
     * @return "growing".
     */
    public String type(){
        return "growing"; //dice que tipo es
    }

    /**
     * When selected, it enlarges its frame by one step, 
     * without exceeding the maximum size.
     */
    @Override
    public void onSelected(){
        if(size < MAX){ //solo crece si no ha llegado al maximo
            size = size + STEP;//aumenta el tamaño de 4 en 4, crece hasta 4 veces
            if(size > MAX){ //no dejamos que se pase del maximo
                size = MAX; //lo recorta al maximo exacto
            }
            setSize(size, size);   
            //aplica el nuevo tamaño al recttangulo
        }
    }
}