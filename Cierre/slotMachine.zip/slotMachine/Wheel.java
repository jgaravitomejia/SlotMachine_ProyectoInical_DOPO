import java.util.ArrayList;
/**
 * Slot machine reel.
 * In Cycle 4, class Standard (normal) reel and base
 * class for the special reels (lefty, rebel).
 * @author GaravitoM-RomanoG
 * @version Cycle 4
 */

// Decisiones de diseno:
//Los atributos y los metodos de apoyo (normalize, draw) son 'protected' para
//que las subclases puedan reutilizarlos.
//type() devuelve "normal" por defecto, cada subclase especial lo redefine.
//allowsLock/allowsSwap/allowsDelete devuelven true por defecto (toda rueda se
//deja manipular), la rueda rebel los redefine para negarse.
//setLeftNeighbor por defecto no hace nada, solo lefty lo aprovecha.

public class Wheel{
    protected ArrayList<Symbol> reel; //simbolos propios de la rueda
    protected  int offset; //indice del simbolo visible 
    protected Rectangle window; //venta, el marco grande de la rueda
    protected int x; //posicion actual de la venta en x 
    protected int y; //posicion actual de la venta en y 
    protected boolean isVisible;
    protected Symbol shown; //symolo que esta dibujado ahora
    protected boolean locked; //pueda o no girar
        
    /**
     * Create a wheel with its own list of symbols.
     * 
     * @param reel symbols for this reel (exclusive, not shared).
     * @param x horizontal position of the window.
     * @param y vertical position of the window.
     */
    public Wheel(ArrayList<Symbol> reel, int x, int y){
        this.reel = reel; //guardamos la lista de los simbolos
        offset = 0; //muestra el que se encuentra en la primera posicion
        window = new Rectangle(); //crea la ventana en las posiciones (70,15) 
        window.changeColor("white");//la venta es blanca
        window.changeSize(60,60); //cambiamos el tamaño
        this.x= 70; 
        this.y = 15;
        isVisible = false; //se crea invisible
        shown = null; //aun no dibujamos nada
        locked = false; //puede girar
        moveTo(x,y); //se mueve hacia donde se le indique
        
    }
    
    /**
     * Returns the wheel type. By default "normal".
     * Each special subclass overrides it with its own type.
     * 
     * @return name of the wheel type.
     */
    public String type(){
        return "normal";
    }
    
    /**
     * Indicates whether this wheel can be locked. By default, yes; Rebel says no.
     *
     * @return true if it can be locked.
     */
    public boolean allowsLock(){
        return true;
    }
    
    /**
     * Indicates whether this wheel can be locked. 
     * By default, yes; Rebel says no.
     * @return true if it can be swapped.
     */
    public boolean allowsSwap(){
        return true;
    }
    
    /**
     * Indicates whether this wheel can be removed. By default, yes; Rebel
     * says no.
     *
     * @return true if it can be removed.
     */
    public boolean allowsDelete(){
        return true;
    }
    
   

    /**
     * Informs this wheel of its left-hand neighbor. By default, it does
     * nothing (a standard wheel doesn't care); 'lefty' stores it for 
     * copying.
     *
     * @param left the wheel to the left of this one, or null 
     * if none exists.
     */
    public void setLeftNeighbor(Wheel left){
        //por defecto, solo LeftWheel lo redefine
    }
    
    /**
     * Rotate the wheel one position.
     */
    public void spin(){
        spin(1); //si solo se quiere girar un paso mas a la rueda
    }
    
    /**
     * Rotates the wheel by several positions. This is the NORMAL 
     * rotation (advancing by its own offset). Subclasses with different
     * behavior (lefty) redefine this.
     * 
     * @param steps number of steps to rotate (positive or negative).
     */
    public void spin(int steps){
        if(locked || reel.isEmpty()){return; }//si esta bloqueada, no hace nada
        int dir; //direccion
        if(steps >= 0){ //si los pasos son positivos, gira hacia adelante
            dir = 1;
        }else{ //si son negativos, gira hacia atras
            dir = -1;
        }
        int count = Math.abs(steps);//cuantas veces va a girar sin importar direc
        for(int k=0; k< count; k++){
            offset = offset + dir; //mueve el offset un lugar
            normalize(); //para que no se salga del rango, normaliza
            draw(); //lo dibuja
        }
        select(); //el simbolo que quedo visible y reacciona
    }
    
    /**
     * Notifies the symbol that ended up visible that it was selected 
     * on the wheel,and redraws. Used by the special Symbol subclasses 
     *(ephemeral shrinks, shy hides/shows). A normal symbol does not 
     *react.
     */
    protected void select(){ //le avisa al simbolo que se encuentra visible
        Symbol s = visibleSymbol();
        if(s != null){
            s.onSelected(); //llama y cada tipo de simbolo sabe que hacer
        }
        draw(); //redibuja para ver el cambio
    }
    
    public void lock(){
        locked = true; //la fija  para que no gire
    }
    
    public void unlock(){ //la libera
        locked = false;
    }
    
    public boolean isLocked(){
        return locked;//informa si esta o no bloqueada
    }
    
    /**
     * Returns the index of the visible symbol (its position within
     * the reel). 
     * It is used by lefty to copy the state of the neighboring reel.
     *
     * @return index of the visible symbol.
     */
    public int currentIndex(){
        return offset; //posicion del simbolo que es visible por el momento
    }
    
    /**
     * Returns the visible symbol of the wheel.
     *
     * @return the visible symbol, or null if the wheel has 
     * no symbols.
     */
    public Symbol visibleSymbol(){
        if(reel.isEmpty()){
            return null;
        }
        return reel.get(offset); //devuelve el simbolo que esta en la posicion
        //visible de la lista, el offseet
        //Asi, slotmchine sabe que color se esta mostrando
    }
    
    /**
     * Forces the wheel to display a specific symbol, based on color.
     *
     * @param symbol The symbol, compared by color, to make visible.
     */
    public void place(Symbol symbol){ //mostrar sin girar deacuerdo al color
        int i = reel.indexOf(symbol);
        //busca en la lista un simbolo igual al recibo
        if(i>=0){
            offset = i;
        }
        draw();
    }
    
    /**
     * Adds a custom symbol to this wheel at a given index.
     *
     * @param index index (0-based) where the symbol is to be inserted.
     * @param color CSS color of the new symbol.
     */
    public void addSymbol(int index, String color){//agregar simbolo sin tipo
        //reutiliza la version con tipo, un simbolo sin tipo es normal
        addSymbol(index, "normal", color);
    }
    
    /**
     * Adds a custom symbol of the given type to this wheel at a given
     * index.
     *
     * @param index index (0-based) where the symbol is to be inserted.
     * @param type symbol type ("normal", "ephemeral", "shy").
     * @param color CSS color of the new symbol.
     */
    public void addSymbol(int index, String type, String color){
        reel.add(index, Symbol.create(type, color));
        //crea el simbolo del tipo e inserta en la posicion index de la lista 
        //de esa rueda
        normalize();
        draw();
    }
    
    /**
     * Remove the symbol for the given color from this wheel.
     *
     * @param color CSS color to remove.
     */
    public void delSymbol(String color){//eliminar por color
        Symbol visible = visibleSymbol();//guarda el simbolo que esta visible
        reel.remove(new Symbol(color)); 
        //simbolo de temporal para buscar por el color
        if(visible != null && visible.getColor().equalsIgnoreCase(color)
            && shown != null){
        //si habia uno visible, que sea del mismo color y que este dibujado
                shown.makeInvisible();
                shown = null; 
        }
        normalize();
        draw();
    }
    
    /**
     * Relocates the wheel to an absolute position on the canvas.
     *
     * @param nx new horizontal position of the window.
     * @param ny new vertical position of the window.
     */
    public void moveTo(int nx, int ny){
        window.moveHorizontal(nx - x);//donde quiere estar - donde esta
        window.moveVertical(ny - y);
        x= nx;
        y = ny;
        draw();
    }
    
    /**
     * It makes the wheel visible.
     */
    public void makeVisible(){
        isVisible = true;
        window.makeVisible();
        draw();
    }
    
    /**
     * It makes the wheel invisible.
     */
    public void makeInvisible(){
        if(shown != null){
            shown.makeInvisible();
        }
        window.makeInvisible();
        shown = null;
        isVisible = false;
    }
    
    /**
     * Adjust the offset to the valid range of the symbol list.
     */
    protected void normalize(){
        if(reel.isEmpty()){
            offset = 0;
            return;
        }
        offset = ((offset % reel.size())+reel.size())% reel.size();
        //hay 3 simbolos offset(0,1,2), si llega a ser 3 vueleve a 0
        //si llega a ser -1 vuelve a 2
    }
    
    /**
     * Draw the visible symbol inside the window, if the wheel is 
     * visible.
     */
    protected void draw(){
        if(!isVisible){ //no dibuja nada, ya se esta viendo
            return;
        }
        Symbol s= visibleSymbol();
        if(shown != null && shown != s){//si habia otro simbolo y diferente
            shown.makeInvisible(); //no se muestra
        }
        if(s != null){
            s.centerIn(x,y,60); //centra el frame
            s.frame();
        }
        shown = s;
    }
}