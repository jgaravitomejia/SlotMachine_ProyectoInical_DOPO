

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Shared test cases for Cycle 3
 *
 * @author  Garavitom-RomanoG
 * @version Cycle 3
 */
public class SlotMachineContestCTest
{
    private SlotMachineContest contest;

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @BeforeEach
    public void setUp(){
        contest = new SlotMachineContest();
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @AfterEach
    public void tearDown(){
    }
    
    @Test
    public void accordingGmRgShouldNotExceedActionLimit(){
        int[][] actions = contest.solve(50);
        assertTrue(actions.length <= 10000);
    }
    
    @Test
    public void accordingGmRgShouldUseValidWheelsAndSteps(){
        int n = 7;
        int[][] actions = contest.solve(n);
        for(int k = 0; k < actions.length; k++){
            int[] act = actions[k];
            assertTrue(act[0] >= 1 && act[0] <= n);
            assertTrue(act[1] != 0);
        }
    }
}